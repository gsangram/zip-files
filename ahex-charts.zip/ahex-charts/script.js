$(document).ready(function () {
    getData();

});
function getData() {
    d3.csv("data.csv", function (error, data) {
        if (error)
            throw error;
        else {
            plotAreaRangeChart("#areRangeChart", data);
        }
    })
}

function plotAreaRangeChart(id, data) {

// set the dimensions and margins of the graph
    var margin = {top: 20, right: 20, bottom: 30, left: 50},
    width = 960 - margin.left - margin.right,
            height = 500 - margin.top - margin.bottom;
var legendsArray =["More Likely",""]
// parse the date / time
    var parseTime = d3.timeParse("%d-%b-%y");

// set the ranges
    var x = d3.scaleTime().range([0, width]);
    var y = d3.scaleLinear().range([height, 0]);

// define the area
    var area = d3.area()
            .x(function (d) {
                return x(d.date);
            })
            .y0(function (d) {
                return y(d.y0)
            })
            .y1(function (d) {
                return y(d.y1);
            });
                       
    var line = d3.line()
            .x(function (d) {
                return x(d.date);
            })
            .y(function (d) {
                return y(d.y)
            });


// append the svg obgect to the body of the page
// appends a 'group' element to 'svg'
// moves the 'group' element to the top left margin
    var svg = d3.select(id).append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform",
                    "translate(" + margin.left + "," + margin.top + ")");



    // format the data
    var data1 = [];
    var data2 = [];
    data.forEach(function (d) {
        console.log('aloo',d);
        d.date = parseTime(d.date);
        d.y = parseFloat(d.y);
        data1.push({
            date: d.date,
            y1: d.y + ((d.y * 5) / 100),
            y0: d.y - ((d.y * 5) / 100)
        });
        data2.push({
            date: d.date,
            y1: d.y + ((d.y * 15) / 100),
            y0: d.y - ((d.y * 15) / 100)
        });
    });
    
 console.log('aloo d1',data1);
 console.log('aloo d2',data2);

    // Scale the range of the data
    x.domain(d3.extent(data, function (d) {
        return d.date;
    }));
    y.domain([d3.min(data2, function (d) {
            return d.y0;
        }), d3.max(data2, function (d) {
            return d.y1;
        })]).nice();
    
    

    // Add the area
    svg.append("path")
            .data([data1])
            .attr("class", "area")
            .attr("d", area)
            .style("opacity", "0.6");
    svg.append("path")
            .data([data2])
            .attr("class", "area")
            .attr("d", area)
//          .style("fill","steelblue")
            .style("opacity", "0.3");
    svg.append("path")
            .data([data])
            .attr("class", "line")
            .attr("d", line)
            .style("stroke", "salmon")
            .style("fill", "none")
            .style("stroke-width","2px");
    
    // Add the scatterplot
    svg.selectAll("dot")	
        .data(data)			
    .enter().append("circle")								
        .attr("r", 3)
        .attr("fill","blue")
        .attr("cx", function(d) { return x(d.date); })		 
        .attr("cy", function(d) { return y(d.y); })	
        
        .on("mouseover", function(d) {		
            div.transition()		
                .duration(200)		
                .style("opacity", .9);		
            div.html("tooltip:<br/>"+d.date + "<br/>"  + d.y)	
                .style("left", (d3.event.pageX) + "px")		
                .style("top", (d3.event.pageY - 28) + "px")	
            })				
        .on("mouseout", function(d) {		
            div.transition()		
                .duration(500)		
                .style("opacity", 0);	
        });
    

//   var legend = svg.selectAll(".legend")
//       .data(options.slice())
//       .enter().append("g")
//       .attr("class", "legend")
//       .attr("transform", function(d, i) {   return "translate(0," + i * 20 + ")";        
//        });
//
//   legend.append("rect")
//      .attr("x", width - 18)
//      .attr("width", 18)
//      .attr("height", 18)
//      .style("fill", color);
//
//   legend.append("text")
//      .attr("x", width - 20)
//      .attr("y", 9)
//      .attr("dy", ".35em")
//      .style("text-anchor", "end")
//      .text(function(d) { return d; });

    // Add the X Axis
    svg.append("g")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(x));

    // Add the Y Axis
    svg.append("g")
            .call(d3.axisLeft(y));



}

