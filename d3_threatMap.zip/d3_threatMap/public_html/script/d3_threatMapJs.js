$(document).ready(function(){
    
   console.log("inside ready()");
var OD_PAIRS = [
        ["CUN", "JFK"],
        ["ORD", "JFK"],
        ["LHR", "BOM"],
        ["LAX", "MEX"],
        ["LHR", "CPT"],
        ["PVG", "CGK"],
        ["SYD", "BOM"],
        ["JFK", "CPT"],
        ["MAD", "GRU"],
        ["EZE", "FCO"],
        ["DEL", "DXB"],
        ["DXB", "NRT"],
        ["GRU", "MIA"],
        ["SVO", "PEK"],
        ["YYZ", "ARN"],
        ["LHR", "YYC"],
        ["HNL", "SEA"],
        ["JFK", "EZE"],
        ["EZE", "LAX"],
        ["CAI", "HKG"],
        ["SVO", "SIN"]
    ];
    mapContainer("#threatmap",OD_PAIRS); 
    
   
    
})  //Closing of ready()  

//  mapContainer() for svg, path and projection for the map
function mapContainer(id,OD_PAIRS){
    var arr={};
    d3.json("data/country.json", function (error, data) {
//                console.log("data.length", data.objects.countries.geometries.length);
                if (error) throw error;
                for (var k = 0; k < data.objects.countries.geometries.length; k++) {
                    var con = data.objects.countries.geometries[k].id;
                    var country = data.objects.countries.geometries[k].properties.name;
                    arr[con]= country;
                }
                 console.log(arr["AGO"]);
//                 loaded.funny();
//                 loaded.int(arr);
//                 loaded(arr);
              
            });
            
    d3.json("data/airport.json", function (error, data) {
        if (error) throw error;
            console.log("airports", data);

    });
   
   
   
//   console.log("hello js",arr["AUS"])
  
    var airportMap = {};
    var markers = [];
    
    var currentWidth = $("#threatmap").width();
    var width = 938;
    var height = 585;
    
    var projection = d3.geo
            .mercator()
            .scale(150)
            .translate([width / 2, height / 1.41]);
    
    var graticuleMini = d3.geo.graticule().step([.5, .5]);
    var graticuleMaxi = d3.geo.graticule().step([10, 10]);

    var path = d3.geo
            .path()
            .pointRadius(2)
            
            .projection(projection);

    var svg = d3.select("#threatmap")
            .append("svg")
            .attr("preserveAspectRatio", "xMidYMid")
            .attr("viewBox", "0 0 " + width + " " + height)
            .attr("width", currentWidth)
            .attr("height", currentWidth * height / width);
    
    var div = d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);
    
     $(window).resize(function () {
        svg.attr("width", currentWidth);
        svg.attr("height", currentWidth * height / width);
    });
    
 
    
     queue().defer(d3.json, "data/country.json")
            .defer(d3.json, "data/airport.json")
            .await(loaded);
       
    function loaded(error, countries, airports) {
        console.log("inside loaded ", arr);             
       
        svg.append("g")
                .attr("class", "countries")
                .selectAll("path")
                .data(topojson.feature(countries, countries.objects.countries).features)
                .enter()
                .append("path")
                .attr("d", path)
                .style("fill", "black")
                .on("mouseover", function (d) {
                    var cont = d3.select(this)
                            .style("opacity", 1)
                            .style("fill", "#12ACE0");
                    div.transition()
                            .duration(200)
                            .style('opacity', 0.9);
                    div.html('<strong>'+d.properties.name+'</strongh>')
                            .style("left", (d3.event.pageX) + "px")
                            .style("top", (d3.event.pageY) + "px");

                }).on("mouseout", function () {
                    d3.select(this)
                            .style("fill", "transparent");
                    div.transition()
                            .duration(500)
                            .style("opacity", 0)
                });
 
//  we can add mouseover, mouseout and click event tooltips over here

        svg.append("path")
                .datum(graticuleMini)
                .attr("class", "graticule")
                .attr("stroke-opacity", 1)
                .attr("d", path);
        
        svg.append("path")
                .datum(graticuleMaxi)
                .attr("class", "graticule")
                .attr("stroke-opacity", 1)     
                .attr("d", path);

        svg.append("g")
                .attr("class", "airports")
                .selectAll("path")
                .data(topojson.feature(airports, airports.objects.airports).features)
                .enter()
                .append("path")
                .attr("id", function (d) {
                    return d.id;
                }).attr("d", path);

        var geos = topojson.feature(airports, airports.objects.airports).features;
      
//        console.log("geos", geos);
//        console.log("airportMap", airportMap);
        
        for (i in geos) {
            airportMap[geos[i].id] = geos[i].geometry.coordinates;
        }
        var i = 0;
        var j = 0;
        
                       
        var int = setInterval(function () {
            
//             console.log("arrrrrrrrrrrrrrr",arr["AUS"]);
            
            if (i > OD_PAIRS.length - 1) {
                i = 0;
                markers = [];
//                clearInterval(int);
            }
            var od = OD_PAIRS[i];
            console.log("od-pairs", od[0], od[1]);
            var odd1= JSON.stringify(od[0]);
            console.log("stringify",odd1)
//            console.log("toString()",od[0].toString());
            console.log("arrrrrrrrrrrrrrr",arr[""]);
            console.log("arrrrzzzzzzzzzzz", arr[odd1]);          
            var d = new Date();
            var hr = d.getHours();
            var min = d.getMinutes();
            var sec = d.getSeconds();
            fly(od[0], od[1], j);         
            $("#latestAttacksContainer").html('<table class="table table-striped" style=""><thead style="color: #12ACE0; line-height: 0"><tr><th>TIME</th><th>ATTACK</th><th>ATTACKING COUNTRY</th><th>TARGET COUNTRY</th></tr></thead>\n\
                                                    <tbody style="color:blue"><tr><td>' + hr + ':' + min + ':' + sec + '</td><td>WANNCRY</td><td>' + arr[od[0]] + '</td><td>' + od[1] + '</td></tr></tbody><br>\n\
                                                    <tbody style="color:blue"><tr><td>' + hr + ':' + min + ':' + sec + '</td><td>LUCKY WANNCRY</td><td>' + arr[od[0]] + '</td><td>' + od[1] + '</td></tr></tbody>\n\
                                                    <tbody style="color:blue"><tr><td>' + hr + ':' + min + ':' + sec + '</td><td>LUCKY WANNCRY</td><td>' +arr[od[0]] + '</td><td>' + od[1] + '</td></tr></tbody></table>');                                              
           
        
            i++;        
            j++;
        }, 500);      
    }    //closing of loaded()  
    
    function fly(origin, destination, i) {
//        console.log('origin',origin);
        var route = svg.append("path").style("fill", "none")
                .datum({type: "LineString", coordinates: [airportMap[origin], airportMap[destination]]})
                .attr("class", "route route_" + i)
                .style("stroke", "#6CB606")
                .style("stroke-width", "2.5")
                .style("fill", "none")
                .attr("d", path);
        var len = route.node().getTotalLength();
        transition(route, i);
    }   // closing of fly()
    
    function transition(route, i) {     
//       console.log("route",route); 
       $("#today").html("<div style='border: 1px solid #12ACE0; border-radius: 20px; text-align: center'><strong><h1>"+i+"</h1></strong></div>");
//        
        var len = route.node().getTotalLength();
        route.attr("stroke-dasharray", len + " " + len)
                .attr("stroke-dashoffset", len)
                .transition()
                .duration(3000)
                .ease("linear")
                .attr("stroke-dashoffset", 0)
                .each("start", marker(0, i))
                .each("end", marker(1, i))
//                .remove();

        function marker(e, i) {
//            console.log("ie", e);
            var dur = 0;
            if (e == 1) {
                dur = 3000;
            }
            var marker_width_height = 15;
//            console.log("co1", route[0][0].__data__.coordinates[e]);
//            console.log("co2", route[0][0].__data__.coordinates[e]);        
//          var  markers=[];
            if (!markers[i]) {
//                console.log("!MARKERS[" + i + "]", markers[i]);
                markers[i] = [];
//                console.log("!markers["+i+"]",markers[i]);
            }
            markers[i].push({
                long: route[0][0].__data__.coordinates[e][0],
                lat: route[0][0].__data__.coordinates[e][1]
            });
//            console.log("array", dur);
            var maa = svg.selectAll(".mark_" + i)
                    .data(markers[i])                
                    .enter()
                    .append("image")
                    .attr('class', 'mark mark_' + i)
                    .attr('width', marker_width_height)
                    .attr('height', marker_width_height)
                    .attr("xlink:href", 'markers/map-marker' + e + '.png')
                    .attr("transform", function (d) {
//                        console.log("e", i, e, d);
                        var pos = projection([d.long, d.lat]);
                        var pos_final = [(pos[0] - (marker_width_height / 2)), (pos[1] - (marker_width_height / 2))];
                        return "translate(" + pos_final + ")";
                    })
                    .style("display", "none");


            setTimeout(function () {
//                console.log(".mark_" + i);
                maa.style("display", "block");
                if (dur != 0) {
//                console.log(".mark_inside" + i);

                    d3.select(".mark_" + i)
                            .attr("opacity", 1)
                            .transition()
                            .duration(2000)
                            .ease("linear")
                            .attr("opacity", 0);
                    d3.select(".route_" + i)
                            .attr("opacity", 1)
                            .transition()
                            .duration(2000)
                            .ease("linear")
                            .attr("opacity", 0);
                    setTimeout(function () {
                        $(".mark_" + i).remove();
                        $(".route_" + i).remove();
                    }, 2000)
                }
            }, dur);
        }
        
        $("#yesterday").html("<div style='border: 1px solid #12ACE0; border-radius: 20px; text-align: center'><strong><h1>3500645</h1></strong></div>");
    }     //closing of transition()
    
    
    $("#target").html('<div class="dropdown" style="margin : 14px"><div class="dropdown">'+
    '<button class="btn btn-default dropdown-toggle" type="button" id="menu1" data-toggle="dropdown">TOP TARGET COUNTRIES <span class="caret"></span></button>'+
    '<ul class="dropdown-menu" role="menu" aria-labelledby="menu1" style="color:blue ;float: right">'+
    '<li role="presentation"><a role="menuitem" href="#">India</a></li>'+
    '<li role="presentation" class="divider"></li>'+
    '<li role="presentation"><a role="menuitem" href="#">Japan</a></li>'+
    '<li role="presentation" class="divider"></li>'+
    '<li role="presentation"><a role="menuitem" href="#">China</a></li>'+
    '<li role="presentation" class="divider"></li>'+
    '<li role="presentation"><a role="menuitem" href="#">Swizerland</a></li>'+
    '</ul></div>');
    
    $("#attacking").html('<div class="dropdown" style="margin : 14px">'+
    '<button class="btn btn-default dropdown-toggle" type="button" id="menu1" data-toggle="dropdown">TOP ATTACKING COUNTRIES<span class="caret"></span></button>'+
    '<ul class="dropdown-menu" role="menu" aria-labelledby="menu1">'+
    '<li role="presentation"><a role="menuitem" href="#">China</a></li>'+
    '<li role="presentation" class="divider"></li>'+
    '<li role="presentation"><a role="menuitem" href="#">america</a></li>'+
    '<li role="presentation" class="divider"></li>'+
    '<li role="presentation"><a role="menuitem" href="#">South Koria</a></li>'+
    '<li role="presentation" class="divider"></li>'+
    '<li role="presentation"><a role="menuitem" href="#">France</a></li>'+
    '</ul></div>');
    
     }   //closing of mapContauiner()
    

