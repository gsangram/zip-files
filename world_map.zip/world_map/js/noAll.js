$(function () {
    var OD_PAIRS = [
        ["NRT", "JFK"],
        ["SFO", "NRT"],
        ["LAX", "HNL"],
        ["HNL", "NRT"],
        ["CDG", "JFK"],
        ["NRT", "SYD"],
        ["FCO", "PEK"],
        ["LHR", "PVG"],
        ["NRT", "ARN"],
        ["LAX", "JFK"],
        ["NRT", "DEL"],
        ["DFW", "GRU"],
        ["MAD", "ATL"],
        ["ORD", "CAI"],
        ["HKG", "CDG"],
        ["LAS", "CDG"],
        ["NRT", "SVO"],
        ["DEN", "HNL"],
        ["ORD", "LAX"],
        ["SIN", "SEA"],
        ["SYD", "PEK"],
        ["CAI", "CPT"],
        ["CUN", "JFK"],
        ["ORD", "JFK"],
        ["LHR", "BOM"],
        ["LAX", "MEX"],
        ["LHR", "CPT"],
        ["PVG", "CGK"],
        ["SYD", "BOM"],
        ["JFK", "CPT"],
        ["MAD", "GRU"],
        ["EZE", "FCO"],
        ["DEL", "DXB"],
        ["DXB", "NRT"],
        ["GRU", "MIA"],
        ["SVO", "PEK"],
        ["YYZ", "ARN"],
        ["LHR", "YYC"],
        ["HNL", "SEA"],
        ["JFK", "EZE"],
        ["EZE", "LAX"],
        ["CAI", "HKG"],
        ["SVO", "SIN"],
        ["IST", "MCO"],
        ["MCO", "LAX"],
        ["FRA", "LAS"],
        ["ORD", "FRA"],
        ["MAD", "JFK"]
    ];

    var currentWidth = $('#map').width();
    var width = 938;
    var height = 620;

    var projection = d3.geo
            .mercator()
            .scale(150)
            .translate([width / 2, height / 1.41]);

    var path = d3.geo
            .path()
            .pointRadius(2)
            .projection(projection);

    var div = d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);

    var div01 = d3.select("body").append("div")
            .attr("class", "tooltip01")
//            .style("display","null")
            .style("opacity", 0);

    var svg = d3.select("#map")
            .append("svg")
            .attr("preserveAspectRatio", "xMidYMid")
            .attr("viewBox", "0 0 " + width + " " + height)
            .attr("width", currentWidth)
            .attr("height", currentWidth * height / width);

    var airportMap = {};
    var markers = [];

    function transition(route, i) {
        var len = route.node().getTotalLength();
        route.attr("stroke-dasharray", len + " " + len)
                .attr("stroke-dashoffset", len)
                .transition()
                .duration(5000)
                .ease("linear")
                .attr("stroke-dashoffset", 0)
                .each("start", marker(0, i))
                .each("end", marker(1, i))
//                .remove();

        function marker(e, i) {
//            console.log("ie", e);
            var dur = 0;
            if (e == 1) {
                dur = 5000;
            }
            var marker_width_height = 15;
//            console.log("co1", route[0][0].__data__.coordinates[e]);
//            console.log("co2", route[0][0].__data__.coordinates[e]);        
//          var  markers=[];
            if (!markers[i]) {
                console.log("!MARKERS[" + i + "]", markers[i]);
                markers[i] = [];
                console.log("!markers["+i+"]",markers[i]);
            }
            markers[i].push({
                long: route[0][0].__data__.coordinates[e][0],
                lat: route[0][0].__data__.coordinates[e][1]
            });
//            console.log("array", dur);
            var maa = svg.selectAll(".mark_" + i)
                    .data(markers[i])                
                    .enter()
                    .append("image")
                    .attr('class', 'mark mark_' + i)
                    .attr('width', marker_width_height)
                    .attr('height', marker_width_height)
                    .attr("xlink:href", 'markers/map-marker' + e + '.png')
                    .attr("transform", function (d) {
                        console.log("e", i, e, d);
                        var pos = projection([d.long, d.lat]);
                        var pos_final = [(pos[0] - (marker_width_height / 2)), (pos[1] - (marker_width_height / 2))];
                        return "translate(" + pos_final + ")";
                    })
                    .style("display", "none");
            
            
      

            setTimeout(function () {
//                console.log(".mark_" + i);
                maa.style("display", "block");
                if (dur != 0) {
//                console.log(".mark_inside" + i);

                    d3.select(".mark_" + i)
                            .attr("opacity", 1)
                            .transition()
                            .duration(2000)
                            .ease("linear")
                            .attr("opacity", 0);
                    d3.select(".route_" + i)
                            .attr("opacity", 1)
                            .transition()
                            .duration(2000)
                            .ease("linear")
                            .attr("opacity", 0);
                    setTimeout(function () {
                        $(".mark_" + i).remove();
                        $(".route_" + i).remove();
                    }, 2000)
                }
            }, dur);
        }
    }

    function fly(origin, destination, i) {
        var route = svg.append("path").style("fill", "none")
                .datum({type: "LineString", coordinates: [airportMap[origin], airportMap[destination]]})
                .attr("class", "route route_" + i)
                .style("stroke", "#C7CA94")
                .style("stroke-width", "1")
                .style("fill", "none")
                .attr("d", path);
        var len = route.node().getTotalLength();
        transition(route, i);
    }

    function loaded(error, countries, airports) {
        svg.append("g")
                .attr("class", "countries")
                .selectAll("path")
                .data(topojson.feature(countries, countries.objects.countries).features)
                .enter()
                .append("path")
                .attr("d", path)
                .style("fill", "black")
                .on("mouseover", function (d) {
//           console.log("data d", d.properties.name);
                    var cont = d3.select(this)
                            .style("opacity", 1)
                            .style("fill", "#E45785");

                    div.transition()
                            .duration(200)
                            .style('opacity', 0.9);

                    div.html(d.properties.name)
                            .style("left", (d3.event.pageX) + "px")
                            .style("top", (d3.event.pageY) + "px");

                })
                .on("click", function (d) {
                    div01.transition()
                            .duration(200)
                            .style('opacity', 1);

                    div01.html(" I am sorry :" + d.properties.name)
                            .style("position", "absolute")
                            .style("width", 'auto')
                            .style("height", '200px')
                            .style("background-color", "brown")
                            .style("color", "blue")
                            .style("padding", 5)
                            .style("left", (d3.event.pageX) + "px")
                            .style("top", (d3.event.pageY) + "px");
                }).on("mouseout", function () {
                    d3.select(this)
                            .style("fill", "black");
                    div.transition()
                            .duration(500)
                            .style("opacity", 0)
                });

        svg.append("g")
                .attr("class", "airports")
                .selectAll("path")
                .data(topojson.feature(airports, airports.objects.airports).features)
                .enter()
                .append("path")
                .attr("id", function (d) {
                    return d.id;
                }).attr("d", path);

        var geos = topojson.feature(airports, airports.objects.airports).features;
        console.log("jeeeeeeee", geos);
        for (i in geos) {
            airportMap[geos[i].id] = geos[i].geometry.coordinates;
        }
        var i = 0;
        var j = 0;
        var int = setInterval(function () {
            if (i > OD_PAIRS.length - 1) {
                i = 0;
                markers = [];
//                clearInterval(int);
            }
            var od = OD_PAIRS[i];
//            console.log("od-pairs",od);
            $("#latestAttacksContainerLeft").html('<table class="table table-striped" ><thead style="color: #E45785;"><tr><th>SOURCE</th><th>TARGET</th><th>SOURCE</th></tr></thead>\n\
                                                       <tbody><tr><td>'+od[0]+'</td><td>'+od[0]+'</td><td>'+od[0]+'</td></tr></tbody><br>\n\
                                                       <tbody ><tr><td>'+od[0]+'</td><td>'+od[0]+'</td><td>'+od[0]+'</td></tr></tbody></table>');                                            
                                                        
            fly(od[0], od[1], j);
            i++;
            j++;
        }, 150);
    }

    queue().defer(d3.json, "data/country.json")
            .defer(d3.json, "data/airport.json")
            .await(loaded);

    $(window).resize(function () {
        currentWidth = $("#map").width();
        svg.attr("width", currentWidth);
        svg.attr("height", currentWidth * height / width);
    });
    
});