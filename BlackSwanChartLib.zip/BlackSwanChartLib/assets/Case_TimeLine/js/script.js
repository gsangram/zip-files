$(document).ready(function () {
     var height = sessionStorage.getItem('f8');

     function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
var widthfrmUrl = getParameterByName("width");
var heightfrmUrl = parseInt(getParameterByName("height"));
if(heightfrmUrl){
height = heightfrmUrl -80;
}


    var options = {
        "container": "#example10", //Container id where chart will be appended
        "header": "CASE TIME LINE", //Heading of Chart
        "uri": "data/data.json", //Url of data
        "height": height
    };
    chartCaseTimeLine(options);//calling chartCaseTimeLine function


});
//---------------------------------------------------------------------------
/**
 *Function to call a function to plot CaseTimeLine chart and to call function on window resize
 */

function chartCaseTimeLine(options)
{
    var CaseTimeLineData = [];//array of data
    var current_options = options;
    loadCaseTimeLineChart(current_options);
//responsivenss
    $(window).on("resize", function () {
        if ($(current_options.continer).find("svg").length != 0) {
            $(current_options.container).empty();
            var data = jQuery.extend(true, [], CaseTimeLineData);
            new CaseTimeLineChart(options);
        }
    });
//---------------------------------------------------------------------------
    /**
     *Function to load data to plot CaseTimeLine chart 
     */
    function loadCaseTimeLineChart(current_options) {
        var uri = current_options.uri;
        d3.json(uri, function (error, data) {
            options.data = jQuery.extend(true, [], data);
            var chart_options = jQuery.extend(true, {}, options);
            var exampleChart = new CaseTimeLineChart(chart_options);

        });
    }

}


