
$(document).ready(function () {

    function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
var widthfrmUrl = getParameterByName("width");
var heightfrmUrl = parseInt(getParameterByName("height"));
if(heightfrmUrl){
height = heightfrmUrl- 50;
}
    var options = {
        "container": "#example20", //Container id where chart will be appended
        "header": "HALO CHART", //Heading of Chart
        "uri": "data/data.json", //Url of data
        "height": 500,
//         colorScale:d3.scale.category20b()
//        tableRefrehView:false
    };
    chartarcbubbbleconnector(options);//calling chartcollapse function
});
//---------------------------------------------------------------------------
/**
 *Function to call a function to plot CaseTimeLine chart and to call function on window resize
 */

function chartarcbubbbleconnector(options)
{
    var chartarcbubbbleData = [];//array of data
    var current_options = options;

    loadfocusChart(current_options);
//responsivenss
    $(window).on("resize", function () {
        if ($(current_options.container).find("svg").length != 0) {
//            $(current_options.container).empty();
//            console.log(options)
//            arcBubbleConnector(options);
        }
    });
    //---------------------------------------------------------------------------
    /**
     *Function to load data to plot CaseTimeLine chart 
     */
    function loadfocusChart(current_options) {
        var uri = current_options.uri;
        d3.json(uri, function (error, data) {
            chartarcbubbbleData = jQuery.extend(true, [], data);
            options.data = jQuery.extend(true, [], data);
            var chart_options = jQuery.extend(true, {}, options);
            arcBubbleConnector(chart_options);
        });
    }



}


