
var lineData = [];
$(document).ready(function () {
//    load data
 var lineData = [];

var height = sessionStorage.getItem('f20');

     function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
var widthfrmUrl = getParameterByName("width");
var heightfrmUrl = parseInt(getParameterByName("height"));
if(heightfrmUrl){
height = heightfrmUrl;
}

 var options={
    container:"#examp",
    height:height,
    width:'900',
    // width:'250',
    gridy:"true",
    uri :"data/data.json" ,
    axisY:"true",
    axisX:"true"
 }
 
loadlineData(options);

   
  });
//responsivenss
    $(window).on("resize", function () {
       loadlineData();
     });

function loadlineData(options){
    var current_options = options;
    console.log(options);
      var lineData = [];
     d3.json(options.uri, function (error, data) {
        console.log(data,options);
lineData=data;
current_options.data=data;
         console.log("datassssssssssssss",data);
         var options = new lineChart(current_options);


   
})
}
//--------------------------------------------------------------------------------------------------------------
