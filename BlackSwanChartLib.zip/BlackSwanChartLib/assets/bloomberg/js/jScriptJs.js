function lineChart(options)
{    
   if (options.container) {
        
        $(options.container).empty();
    }
    if(options)
{
    options.container=options.container?options.container:"body"
    options.width=options.width?options.width:$(options.container).width()-10
    options.height=options.height?options.height:300
    options.marginTop=options.marginTop?options.marginTop:100
    options.marginBottom=options.marginBottom?options.marginBottom:100
    options.marginRight=options.marginRight?options.marginRight:300
    options.marginLeft=options.marginLeft?options.marginLeft:100
    options.xParam=options.xParam?options.xParam:$('#errormsg').html('Please check ... May be Data,x-Parameter or y-Parameter is missing.. ');
    options.yParam=options.yParam?options.yParam:$('#errormsg').html('Please check ... May be Data,x-Parameter or y-Parameter is missing.. ');
    options.gridx=options.gridx?options.gridx:false
    options.gridy=options.gridy?options.gridy:false
    options.axisX=options.axisX?options.axisX:false
    options.axisY=options.axisY?options.axisY:false
    options.randomIdString = Math.floor(Math.random() * 10000000000)
    options.bloombergHeader = options.header ? options.header : "BLOOMBERG CHART";
    options.headerOptions = options.headerOptions == false ? options.headerOptions : true;







 }   

var data = [];


   var actualOptions = jQuery.extend(true, {}, options);

    var randomSubstring = options.randomIdString;
    var h = options.height;
    var header =  options.bloombergHeader;
    var containerid = options.container;
    var _this = options;
    var modalwidth = $(window).width() - 200;
    var modal = ' <div id="modal_' + randomSubstring + '"class="modal fade " tabindex="-1" role="dialog"> <div class="modal-dialog modal-lg" style="width:' + modalwidth + 'px"> <form ><div class="modal-content"><div class="modal-body"  style="padding:0;background-color:#334d59" id="modal_chart_container' + randomSubstring + '"></div></div></form></div></div>';
    //var chartContainerdiv = '<div class="chartContainer"  align="center" style="width: 100%; margin: auto; margin-top: 0px; font-size: 14px;font-style: inherit;"> <div class="graphBox" style="height:'+h+'px;max-height: '+h+'px;min-height: '+h+'px;margin: auto; background-color: #374c59; width: 100%;left: 0px;top: 0px;position: relative;"> <div class="headerDiv" style="font-weight:bold;background-color: #425661;text-align: left;color: #239185; border-bottom: 1px solid rgba(192, 192, 192, 0.47);width: 100%; line-height: 2.5;font-size: 16px ;padding-left: 5px;">' + header + '</div><div id="bubble_chart_div' + randomSubstring + '" class="chartContentDiv" style="width: 100%;"></div> </div></div>'
    // var chartContainerdiv = '<div class="chartContainer"  align="center" style="width: 80%; margin: auto; margin-top: 30px; font-size: 14px;font-family: roboto-regular;"> <div class="graphBox" style="margin: auto; background-color: #374c59; width: 100%;left: 0px;top: 0px;overflow: hidden;position: relative;"> <div class="headerDiv" style="font-weight:bold;background-color: #425661;text-align: left;color: #239185; border-bottom: 1px solid rgba(192, 192, 192, 0.47);width: 100%; line-height: 2.5;font-size: 16px ;padding-left: 5px;">' + this.bubbleHeader + '</div><div id="bubble_chart_div' + randomSubstring + '" class="chartContentDiv" style="width: 100%;"></div> </div></div>'

    var chartContainerdiv = '<div class="chartContainer"  align="center" style="width: 100%; margin: auto; margin-top: 0px; font-size: 14px;font-style: inherit;"> <div class="graphBox" style="height:' + h + 'px;max-height: ' + h + 'px;min-height: ' + h + 'px;margin: auto; background-color: #374c59; width: 100%;left: 0px;top: 0px;position: relative;"> <div class="headerDiv" style="font-weight:bold;background-color: #425661;text-align: left;color: #239185; border-bottom: 1px solid rgba(192, 192, 192, 0.47);width: 100%; line-height: 2.5;font-size: 16px ;padding-left: 5px;">' + header + '</div><div id="bloomberg_chart_div' + randomSubstring + '" class="chartContentDiv" style="width: 100%;"></div> </div></div>'

    $(containerid).html(chartContainerdiv);
    $(containerid).append(modal);
    var chart_container = "#bloomberg_chart_div" + randomSubstring;
   if (!options.headerOptions) {
        var closebtn = '<button type="button" class="cancel" style="float: right;padding:0 8px;border:0;opacity: 1;background-color: transparent;float:right" data-dismiss="modal" aria-label="Close"> <span class="fa fa-remove"></span></button>'
        $(chart_container).siblings(".headerDiv").append(closebtn);
    }

    if ($(chart_container).siblings(".headerDiv").find(".bstheme_menu_button").length == 0)
        var header_options = '<div style="float: right; padding: 0 10px; cursor: pointer;" class="bstheme_menu_button bstheme_menu_button_' + randomSubstring + '" data-toggle="collapse" data-target="#opt_' + randomSubstring + '"><i class="fa fa-ellipsis-v" aria-hidden="true"></i><div class="bstheme_options" style="position:absolute;right:10px;z-index:2000"> <div style="display:none; min-width: 120px; margin-top: 2px; background: rgb(27, 39, 53) none repeat scroll 0% 0%; border: 1px solid rgb(51, 51, 51); border-radius: 4px;" id="opt_' + randomSubstring + '" class="collapse"><span style="display: inline-block;float: left;text-align: center;width: 33.33%; border-right: 1px solid #000;" class="header_fullscreen_chart' + randomSubstring + '"><i class="fa fa-expand" aria-hidden="true"></i></span><span style="display: inline-block;float: left;text-align: center;width: 33.33%; border-right: 1px solid #000;" class="header_refresh_' + randomSubstring + '"><i class="fa fa-refresh" aria-hidden="true"></i></span> <span style="display: inline-block;float: left;text-align: center;width: 33.33%;" class="header_table_' + randomSubstring + '"> <i class="fa fa-table" aria-hidden="true"></i></span> <span style="display: none;float: left;text-align: center;width: 33.33%;" class="header_chart_' + randomSubstring + '" ><i class="fa fa-bar-chart" aria-hidden="true"></i></span></div></div> </div>';
    $(chart_container).siblings(".headerDiv").append(header_options);

    if (!options.headerOptions) {
        $(chart_container).siblings(".headerDiv").find(".bstheme_options").css("right", "28px");
        $('.header_fullscreen_chart' + randomSubstring).css("display", "none");
    } else {
        $(chart_container).siblings(".headerDiv").find(".bstheme_options").css("right", "0");
    }
    root = options.data;


    //  $(".graphBox").mCustomScrollbar({
    //     axis: "y",
    //    //theme: "3d"
    // });
    var data = options.data;
    var curretn_uri = options.Uri;
    var bubble_header = options.bloombergHeader;








var tool_tip = $('body').append('<div class="line_Chart_tooltip" style="position: absolute; opacity: 1; pointer-events: none; visibility: hidden;background-color:#FB8B1E;padding: 10px;border-radius: 5px;border: 1px solid gray;font-size: 10px;color:black;"><span style=" font-size: 12px; position: absolute; white-space: nowrap;  margin-left: 0px; margin-top: 0px; left: 8px; top: 8px;"><span style="font-size:10px" class="tool_tip_x_val"></span><table><tbody><tr><td style="padding:0"> </td><td style="padding:0"><b>216.4 mm</b></td></tr><tr><td style="color:#434348;padding:0">New York: </td><td style="padding:0"><b>91.2 mm</b></td></tr><tr><td style="color:#90ed7d;padding:0">London: </td><td style="padding:0"><b>52.4 mm</b></td></tr><tr><td style="color:#f7a35c;padding:0">Berlin: </td><td style="padding:0"><b>47.6 mm</b></td></tr></tbody></table></span></div>');

// basic SVG setup
var margin = {top:  options.marginTop, right:  options.marginRight, bottom: options.marginBottom, left:  options.marginLeft},
    width =   options.width - margin.left - margin.right,
    height =  options.height - margin.top - margin.bottom;


var svg = d3.select(chart_container).append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");



// setup scales - the domain is specified inside of the function called when we load the data
var xScale = d3.scaleTime().rangeRound([0, width]);
var yScale = d3.scaleLinear().rangeRound([height, 0]);


// set the line attributes
var line = d3.line()
        .x(function (d) {
            return xScale(d.year); })  
        .y(function (d) {
            return yScale(d.value); }); 

var area = d3.area()
        .x(function (d) {
            return xScale(d.year); })
        .y1(function (d) {
            return yScale(d.value); }); 

var lineSvg = svg.append("g");                             
    


// gridlines function in y axis function
function make_y_gridlines() {		
    return d3.axisLeft(yScale)
        .ticks(5)
};
function make_x_gridlines() {   
    return d3.axisBottom(yScale)
        .ticks(5)
};


var parseTime = d3.timeParse("%d-%b-%y");
bisectDate = d3.bisector(function(d) { return d.year; }).left ;

data=options.data;

    data.forEach(function(d) {
      d.year = parseTime(d.year);
      d.value = +d.value;
  });


    // adding domain range to the x-axis 
    xScale.domain(d3.extent(data, function(d) { return d.year; }));
    // add domain ranges to the x and y scales
    yScale.domain([
        d3.min(data, function (c) {
            return c.value ; }),        
        d3.max(data, function (c) {
            return c.value ; })
        ]);
        area.y0(height);


   
      // add the Y gridlines
  svg.append("g")     
      .attr("class", "bs_linegrid")
      .attr("fill","white")
      .call(make_y_gridlines()
          .tickSize(-width)
          .tickFormat("")
      )


  // add the x axis
    svg.append("g")
            .attr("class", "x axis x_axis")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(xScale).ticks(5)).style("stroke","#7B7D80").style("font-family","Roboto Light");
    
    // add the y axis
    svg.append("g")
            .attr("class", "y axis y_axis")
            .attr("transform", "translate("+width+",0)")
            .call(d3.axisRight(yScale).ticks(5)).style("stroke","#7B7D80").style("font-family","Roboto Light");

 // add the area
    svg.append("path")
//       .datum(data)
       .attr("fill",'#4A413A')
       .attr("class", "area")
       .attr("d", area(data));

  // add the valueline path.
    svg.append("path")
      .data([data])
      .attr("class", "line")
      .attr("d", line).attr("fill",'none').attr('stroke','#FB8B1E').attr('stroke-width','3px');
     
   


     var focus = svg.append("g")                  
    .style("display", "none");

    //  for tooltip and labels---------------------------->>>>>>>>                          
    
    // append the rectangle to capture mouse               
    var rect= svg.append("rect").attr('class','tool')                                    
        .attr("width", width)                              
        .attr("height", height)                            
        .style("fill", "none")                           
        .style("pointer-events", "all")                    
        .on("mouseover", function() { focus.style("display",'block'); })
        .on("mouseout", function() { focus.style("display", "none"); })
        .on("mousemove", mousemove);                       

    
function mousemove() {

        var x0 = xScale.invert(d3.mouse(this)[0]),              
            i = bisectDate(data, x0, 1),                   
            d0 = data[i - 1],                             
            d1 = data[i],                                  
            d = x0 - d0.year > d1.year - x0 ? d1 : d0;   
            
            var myDate = new Date(d.year);
           // console.log(myDate.getFullYear(),myDate.getDate(),myDate.getMonth())
           
      focus.selectAll(".x").remove() ;       
   // append the x line;
      focus.append("line")
        .attr("class", "x")
        .style("stroke", "#FB8B1E")
        .style("stroke-dasharray", "3,3")
        .style("opacity", 01)
        .attr("y1", 0)
        .attr("y2", height); 
    

   focus.selectAll(".y0").remove()   
   // append the circle at the intersection
    focus.append("circle")
        .attr("class", "y0")
        .style("fill", "#FB8B1E")
        .style("stroke", "white")
        .attr("r", 6);

  // Rect for tooltip year
   
  focus.selectAll(".y1").remove()   
  focus.append("rect")
   .attr("class", "y1")
   .attr("width", "100px").style('fill','#FB8B1E')
   .attr("height", "20px") .attr("transform",
            "translate(" + (xScale(d.year)-50) + "," +
                           (height+5)+ ")");;
  focus.append("text")
    .attr("class", "y1").style("font-weight","normal").style("font-family","Roboto Light")
    .style("stroke", "#000")
    .attr("dx", 12)
    .attr("dy", "13px");

  // Rect for tooltip value

  // focus.selectAll(".y2").remove()   
  // focus.append("rect")
  //   .attr("class", "y2")
  //   .attr("width", "70px").style('fill','#FB8B1E')
  //   .attr("height", "20px") .attr("transform",
  //           "translate(" + (xScale(d.year)-90) + "," +
  //                          (height+5)+ ")");;
  // focus.append("text")
  //   .attr("class", "y2").style("font-weight","normal").style("font-family","Roboto Light")
  //   .style("stroke", "#374C59")
  //   .attr("dx", 12)
  //   .attr("dy", "13px");



focus.select("circle.y0")
      .attr("transform",
            "translate(" + xScale(d.year) + "," +
                           yScale(d.value) + ")");
                           
  
//Text for year
focus.select("text.y1").style("font-weight","normal")
  .attr("transform",
            "translate(" + (xScale(d.year)-55) + "," +
                           (height+7) + ")")
                          .text(myDate.getFullYear()+':'+d.value);
// Text for value
// focus.select("text.y2").style("font-weight","normal")
//   .attr("transform",
//             "translate(" + (xScale(d.year)-90) + "," +
//                            (height+7) + ")")
//                           .text(d.value);

focus.select(".x")
  .attr("transform",
              "translate(" + xScale(d.year) + ",0)")                       
                 .attr("y2", height);

          } 








      //------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */
    $("body").on("click", ".bstheme_menu_button_" + randomSubstring, function () {
        var id = ($(this).attr("data-target"));
        if ($(id).css("display") == "none") {
            $(id).css("display", "inline-block");
        } else {
            $(id).css("display", "none");
        }
    });
//------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */
    $("body").on("click", ".header_refresh_" + randomSubstring, function () {
        var chartId = $(this).parent().parent().parent().parent().siblings("div").attr("id");
        if ("#" + chartId == chart_container) {
            $(containerid).empty();

            loadlineData(actualOptions);
        }
    });
//------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */

    $("body").on("click", ".header_table_" + randomSubstring, function () {

        $(chart_container).empty();
        $(this).css("display", "none");
        $(".header_chart_" + randomSubstring).css("display", "inline-block");
        // var newdata=data.nodes;

        var tbl = "<div id ='bloomberg_table_" + randomSubstring + "'  style='padding:5px;background-color: #425661;overflow:overflow:hidden;height:" + (_this.height) + "px'><table id ='bloomberg_table1_" + randomSubstring + "' class='table-striped ' style='width:100%;background-color:#283C45;padding:5px;color:#5A676E; ' ><thead><tr><th>VALUE</th><th>YEAR</th></tr></thead><tbody>";
console.log(data)
        $.each(data, function (i, v) {
          console.log(v)
                tbl = tbl + "<tr><td>" + (v.value) + "</td><td>" + v.year + "</td></tr>"

        });
        tbl = tbl + "</tbody></table></div>";
        $(chart_container).append(tbl);
        $("#bloomberg_table1_" + randomSubstring).DataTable({"bLengthChange": false, "paging": false, "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (iDisplayIndex % 2 == 1) {
                    //even color
                    $('td', nRow).css('background-color', '#32464F');
                } else {
                    $('td', nRow).css('background-color', '#283C45');
                }
            }});
        $("#bloomberg_table_" + randomSubstring).mCustomScrollbar({
            axis: "y"
        });

        $("#bloomberg_table_" + randomSubstring + " tr:first").css("background-color", "#0CB29A");
        var id1 = $("#bloomberg_table_" + randomSubstring).children('div').find('div').eq(0);
        var id2 = $("#bloomberg_table_" + randomSubstring).children('div').find('div').eq(1);
        var id3 = $("#bloomberg_table_" + randomSubstring).children('div').find('div').eq(2);
        var id1attr = id1.attr("id");
        var id2attr = id2.attr("id");
        var id3attr = id3.attr("id");



        $("#" + id1attr + " " + "label").css("color", "#666666")
        $("#" + id2attr + " " + "label").css("color", "#666666")
        $("#" + id3attr).css("color", "#666666")

        $(" .dataTables_filter input").css({"margin-left": "0.5em", "position": "relative", "border": "0", "min-width": "240px",
            "background": "transparent",
            "border-bottom": "1px solid #666666",
            " border-radius": " 0",
            "padding": " 5px 25px",
            "color": "#ccc",
            "height": " 30px",
            "-webkit-box-shadow": " none",
            "box-shadow": " none"
        })



    });








//------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */
    $("body").on("click", ".header_chart_" + randomSubstring, function () {
        $(chart_container).css("overflow", "hidden");
        var chartId = $(this).parent().parent().parent().parent().siblings("div").attr("id");
        if ("#" + chartId == chart_container) {
            $(this).css("display", "none");
            $(".header_table_" + randomSubstring).css("display", "inline-block");
            $(containerid).empty();
            new lineChart(actualOptions);
        }
    });

//------------------------------------------------------------------------------------------------

    $("body").on("click", ".header_fullscreen_chart" + randomSubstring, function () {
//       $("#modal_"+randomSubstring).modal("show");
        $("#modal_" + randomSubstring).modal('show');
        var options = jQuery.extend(true, {}, actualOptions);
        setTimeout(function () {
            $("#modal_chart_container" + randomSubstring).css("width", "100%")
            options.container = "#modal_chart_container" + randomSubstring;
            options.headerOptions = false;
            options.height = 450;
            new lineChart(options);
        }, 500)

        //"modal_chart_container"+randomSubstring
    })
          



}