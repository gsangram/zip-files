function lineChart(options)
{

    if (options)
    {
        options.container = options.container ? options.container : "body"

        options.height = options.height ? options.height : 300
        options.marginTop = options.marginTop ? options.marginTop : 30
        options.marginBottom = options.marginBottom ? options.marginBottom : 30
        options.marginRight = options.marginRight ? options.marginRight : 20
        options.marginLeft = options.marginLeft ? options.marginLeft : 50
        options.xParam = options.xParam ? options.xParam : $('#errormsg').html('Please check ... May be Data,x-Parameter or y-Parameter is missing.. ');
        options.yParam = options.yParam ? options.yParam : $('#errormsg').html('Please check ... May be Data,x-Parameter or y-Parameter is missing.. ');
        options.gridx = options.gridx ? options.gridx : false
        options.gridy = options.gridy ? options.gridy : false
        options.randomIdString = Math.floor(Math.random() * 10000000000);
        options.header = options.header ? options.header : "LINE CHART";
        options.headerOptions = options.headerOptions == false ? options.headerOptions : true;

    }

    var actualOptioins = jQuery.extend(true, {}, options);

    var data = options.data;
    var actualOptioins = jQuery.extend(true, {}, options);
    var header = options.header;
    var containerid = options.container;
    var randomSubstring = options.randomIdString;
    // var chartContainerdiv = '<div class="chartContainer"  align="center" style="width: 80%; margin: auto; margin-top: 30px; font-size: 14px;font-style: inherit;"> <div class="graphBox" style="margin: auto; background-color: #374c59; width: 100%;left: 0px;top: 0px;overflow: hidden;position: relative;"> <div class="headerDiv" style="font-weight:bold;background-color: #425661;text-align: left;color: #239185; border-bottom: 1px solid rgba(192, 192, 192, 0.47);width: 100%; line-height: 2.5;font-size: 16px ;padding-left: 5px;">' + header + '</div><div id="line_chart_div' + randomSubstring + '" class="chartContentDiv" style="width: 100%;"></div> </div></div>'

    var h1 = options.height;
    var h = parseInt(h1) + 50;

    var _this = options;
    var modalwidth = $(window).width() - 200;
    var modal = ' <div id="modal_' + randomSubstring + '"class="modal fade " tabindex="-1" role="dialog"> <div class="modal-dialog modal-lg" style="width:' + modalwidth + 'px"> <form ><div class="modal-content"><div class="modal-body"  style="padding:0;background-color:#334d59" id="modal_chart_container' + randomSubstring + '"></div></div></form></div></div>';

    var chartContainerdiv = '<div class="chartContainer"  align="center" style="width: 100%; margin: auto; margin-top: 0px; font-size: 14px;font-style: inherit;"> <div class="graphBox" style="height:' + h + 'px;max-height: ' + h + 'px;min-height: ' + h + 'px;margin: auto; background-color: #374c59; width: 100%;left: 0px;top: 0px;position: relative;"> <div class="headerDiv" style="font-weight:bold;background-color: #425661;text-align: left;color: #239185; border-bottom: 1px solid rgba(192, 192, 192, 0.47);width: 100%; line-height: 2.5;font-size: 16px ;padding-left: 5px;">' + header + '</div><div id="line_chart_div' + randomSubstring + '" class="chartContentDiv" style="width: 100%;"></div> </div></div>'
    $(options.container).html(chartContainerdiv);
    $(options.container).append(modal);
    var chart_container;

    var chart_container = "#line_chart_div" + randomSubstring;

    options.width = options.width ? options.width : $(chart_container).width() - 10
    if (!options.headerOptions) {
        var closebtn = '<button type="button" class="cancel" style="float: right;padding:0 8px;border:0;opacity: 1;background-color: transparent;float:right" data-dismiss="modal" aria-label="Close"> <span class="fa fa-remove"></span></button>'
        $(chart_container).siblings(".headerDiv").append(closebtn);
    }

    if ($(chart_container).siblings(".headerDiv").find(".bstheme_menu_button").length == 0)
        var header_options = '<div style="float: right; padding: 0 10px; cursor: pointer;" class="bstheme_menu_button bstheme_menu_button_' + randomSubstring + '" data-toggle="collapse" data-target="#opt_' + randomSubstring + '"><i class="fa fa-ellipsis-v" aria-hidden="true"></i><div class="bstheme_options" style="position:absolute;right:10px;z-index:2000"> <div style="display:none; min-width: 120px; margin-top: 2px; background: rgb(27, 39, 53) none repeat scroll 0% 0%; border: 1px solid rgb(51, 51, 51); border-radius: 4px;" id="opt_' + randomSubstring + '" class="collapse"><span style="display: inline-block;float: left;text-align: center;width: 33.33%; border-right: 1px solid #000;" class="header_fullscreen_chart' + randomSubstring + '"><i class="fa fa-expand" aria-hidden="true"></i></span><span style="display: inline-block;float: left;text-align: center;width: 33.33%; border-right: 1px solid #000;" class="header_refresh_' + randomSubstring + '"><i class="fa fa-refresh" aria-hidden="true"></i></span> <span style="display: inline-block;float: left;text-align: center;width: 33.33%;" class="header_table_' + randomSubstring + '"> <i class="fa fa-table" aria-hidden="true"></i></span> <span style="display: none;float: left;text-align: center;width: 33.33%;" class="header_chart_' + randomSubstring + '" ><i class="fa fa-bar-chart" aria-hidden="true"></i></span></div></div> </div>';
    $(chart_container).siblings(".headerDiv").append(header_options);

    if (!options.headerOptions) {
        $(chart_container).siblings(".headerDiv").find(".bstheme_options").css("right", "28px");
        $('.header_fullscreen_chart' + randomSubstring).css("display", "none");
    } else {
        $(chart_container).siblings(".headerDiv").find(".bstheme_options").css("right", "0");
    }
    var tool_tip = $('body').append('<div class="line_Chart_tooltip" style="position: absolute; opacity: 1; pointer-events: none; visibility: hidden;background-color:#0cae96;padding: 10px;border-radius: 5px;border: 1px solid gray;font-size: 10px;color:black;"><span style=" font-size: 12px; position: absolute; white-space: nowrap;  margin-left: 0px; margin-top: 0px; left: 8px; top: 8px;"><span style="font-size:10px" class="tool_tip_x_val"></span><table><tbody><tr><td style="padding:0"> </td><td style="padding:0"><b>216.4 mm</b></td></tr><tr><td style="color:#434348;padding:0">New York: </td><td style="padding:0"><b>91.2 mm</b></td></tr><tr><td style="color:#90ed7d;padding:0">London: </td><td style="padding:0"><b>52.4 mm</b></td></tr><tr><td style="color:#f7a35c;padding:0">Berlin: </td><td style="padding:0"><b>47.6 mm</b></td></tr></tbody></table></span></div>');

    var colorScale = d3.scaleOrdinal().range(["#46a2de", "#5888C8", "#31d99c", "#de5942", "#ffa618"]);
    var svg = d3.select(chart_container).append("svg").attr("width", options.width).attr("height", options.height),
            margin = {top: options.marginTop, right: options.marginRight, bottom: options.marginBottom, left: options.marginLeft},
    width = options.width - margin.left - margin.right,
            height = options.height - margin.top - margin.bottom;


    var parseTime = d3.timeParse("%Y");
    bisectDate = d3.bisector(function (d) {
        return d.year;
    }).left;

    var x = d3.scaleTime().range([0, width]);
    var y = d3.scaleLinear().range([height, 0]);


//------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */
    $("body").on("click", ".bstheme_menu_button_" + randomSubstring, function () {

        var id = ($(this).attr("data-target"));
        if ($(id).css("display") == "none") {
            $(id).css("display", "inline-block");
        } else {
            $(id).css("display", "none");
        }
    });
//------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */
    $("body").on("click", ".header_refresh_" + randomSubstring, function () {
        var chartId = $(this).parent().parent().parent().parent().siblings("div").attr("id");
        if ("#" + chartId == chart_container) {
            $(containerid).empty();
            loadlineData(options);
        }
    });
//------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */


    $("body").on("click", ".header_table_" + randomSubstring, function () {

        $(chart_container).empty();
        $(this).css("display", "none");
        $(".header_chart_" + randomSubstring).css("display", "inline-block");
        // var newdata=data.nodes;

        var tbl = "<div id ='line_chart_table_" + randomSubstring + "'  style='padding:5px;background-color: #425661;overflow:overflow:hidden;height:" + (_this.height) + "px'><table id ='line_chart_table1_" + randomSubstring + "' class='table-striped ' style='width:100%;background-color:#283C45;padding:5px;color:#5A676E; ' ><thead><tr><th>YEAR</th><th>VALUE</th></tr></thead><tbody>";
        $.each(data, function (index, value) {

            tbl = tbl + "<tr><td>" + (value.year) + "</td><td>" + value.value + "</td></tr>"

        });
        tbl = tbl + "</tbody></table></div>";
        $(chart_container).append(tbl);
        $("#line_chart_table1_" + randomSubstring).DataTable({"bLengthChange": false, "paging": false, "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (iDisplayIndex % 2 == 1) {
                    //even color
                    $('td', nRow).css('background-color', '#32464F');
                } else {
                    $('td', nRow).css('background-color', '#283C45');
                }
            }});
        $("#line_chart_table_" + randomSubstring).mCustomScrollbar({
            axis: "y"
        });

        $("#line_chart_table_" + randomSubstring + " tr:first").css("background-color", "#0CB29A");
        var id1 = $("#line_chart_table_" + randomSubstring).children('div').find('div').eq(0);
        var id2 = $("#line_chart_table_" + randomSubstring).children('div').find('div').eq(1);
        var id3 = $("#line_chart_table_" + randomSubstring).children('div').find('div').eq(2);
        var id1attr = id1.attr("id");
        var id2attr = id2.attr("id");
        var id3attr = id3.attr("id");



        $("#" + id1attr + " " + "label").css("color", "#666666")
        $("#" + id2attr + " " + "label").css("color", "#666666")
        $("#" + id3attr).css("color", "#666666")

        $(" .dataTables_filter input").css({"margin-left": "0.5em", "position": "relative", "border": "0", "min-width": "240px",
            "background": "transparent",
            "border-bottom": "1px solid #666666",
            " border-radius": " 0",
            "padding": " 5px 25px",
            "color": "#ccc",
            "height": " 30px",
            "-webkit-box-shadow": " none",
            "box-shadow": " none"
        })



    });


//------------------------------------------------------------------------------
    /**
     * Fuction to handle show chart
     */
    $("body").on("click", ".header_chart_" + randomSubstring, function () {
        var chartId = $(this).parent().parent().parent().parent().siblings("div").attr("id");
        if ("#" + chartId == chart_container) {
            $(this).css("display", "none");
            $(".header_table_" + randomSubstring).css("display", "inline-block");
            $(containerid).empty();

            new lineChart(actualOptioins);
        }
    });











    //------------------------------------------------------------------------------------------------

    $("body").on("click", ".header_fullscreen_chart" + randomSubstring, function () {
//       $("#modal_"+randomSubstring).modal("show");
        $("#modal_" + randomSubstring).modal('show');
        var options = jQuery.extend(true, {}, actualOptioins);
        setTimeout(function () {
            $("#modal_chart_container" + randomSubstring).css("width", "100%")
            options.container = "#modal_chart_container" + randomSubstring;
            options.headerOptions = false;
            options.height = 450;
            new lineChart(options);
        }, 500)

        //"modal_chart_container"+randomSubstring
    })

    function make_x_axis() {
        return d3.axisBottom(x)

        //    .ticks(8)

    }


    function make_y_axis() {
        return d3.axisLeft(y)
        //  .ticks(8);
    }

    var line = d3.line()


            .x(function (d) {
                return x(d.year);
            })
            .y(function (d) {
                return y(d.value);
            });

    var g = svg.append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


    var linedata = options.data;

    if (linedata) {
        if (linedata.length)
            drawline(linedata);
    } else {
        console.error("Data Handling Error : No data To plot the graph");
    }

    function drawline(data)
    {


        x.domain(d3.extent(data, function (d) {
            return d.year;
        }));
        y.domain([d3.min(data, function (d) {
                return d.value;
            }) / 1.005, d3.max(data, function (d) {
                return d.value;
            }) * 1.005]);


        //   .text("Population)");

        if (options.gridx == true)
        {

            var x_g = g.append("g")
                    .attr("class", "bs_linegrid")
                    .attr("transform", "translate(0," + height + ")")
                    //  .attr("class","gridx").style("fill","red")
                    .call(make_x_axis()
                            .tickSize(-height, 0, 0)
                            .tickFormat("")
                            );
            x_g.selectAll("path").style("stroke", "#6c7e88")
                    .style("shape-rendering", "crispEdges")
                    .style("fill", "none");
            x_g.selectAll("line").style("stroke", "#6c7e88")
                    .style("shape-rendering", "crispEdges")
                    .style("fill", "none");
            x_g.selectAll("text").style("fill", "#6c7e88")
                    .style("font-size", "10px")
                    .style("stroke", "none");


        }
        if (options.gridy == true)
        {

            var y_g = g.append("g")
                    .attr("class", "bs_linegrid")
                    .call(make_y_axis()
                            .tickSize(-width, 0, 0)
                            .tickFormat("")
                            );
            y_g.selectAll("text").style("fill", "#6c7e88")
                    .style("font-size", "10px")
                    .style("stroke", "none");
            y_g.selectAll("path").style("stroke", "#6c7e88")
                    .style("shape-rendering", "crispEdges")
                    .style("fill", "none");
            y_g.selectAll("line").style("stroke", "#6c7e88")
                    .style("shape-rendering", "crispEdges")
                    .style("fill", "none");

        }


        var x_g = g.append("g")
                .attr("class", "bs_axisX").style("stroke", "#6C7E88")
                .attr("transform", "translate(0," + height + ")")
                //   .attr("transform", "rotate(0)")
                .call(d3.axisBottom(x))
        x_g.selectAll("path").style("stroke", "#6c7e88")
                .style("shape-rendering", "crispEdges")
                .style("fill", "none");
        x_g.selectAll("line").style("stroke", "#6c7e88")
                .style("shape-rendering", "crispEdges")
                .style("fill", "none");
        x_g.selectAll("text").style("fill", "#6c7e88")
                .style("font-size", "10px")
                .style("stroke", "none");

        var y_g = g.append("g")
                .attr("class", "bs_axisY").style("stroke", "#6C7E88")
                .call(d3.axisLeft(y).tickFormat(function (d) {
                    return parseInt(d / 1000) + "k";
                }));
        y_g.append("text")
                .attr("class", "axis-title")
                .attr("transform", "rotate(-90)")
                .attr("y", 6)
                .attr("dy", ".71em")
                .style("text-anchor", "end")
                .attr("fill", "#5D6971")
                .style("font-size", "20px")
        y_g.selectAll("text").style("fill", "#6c7e88")
                .style("font-size", "10px")
                .style("stroke", "none");
        y_g.selectAll("path").style("stroke", "#6c7e88")
                .style("shape-rendering", "crispEdges")
                .style("fill", "none");
        y_g.selectAll("line").style("stroke", "#6c7e88")
                .style("shape-rendering", "crispEdges")
                .style("fill", "none");


        // path = g.append("path")
        //         .data([data])
        //         .attr("class", "bs_line").style("fill", "none").style("stroke", "#3E818C").style("shape-rendering", "crispEdges")

        //         .attr("d", line).transition().duration(400).ease(d3.easeLinear);

        var focus = g.append("g")
                .attr("class", "focus")
                .style("display", "none");

        focus.append("line")
                .attr("class", "x-hover-line hover-line")
                .attr("y1", 0)
                .attr("y2", height);

        focus.append("line")
                .attr("class", "y-hover-line hover-line")
                .attr("x1", width)
                .attr("x2", width);

        focus.append("circle")
                .attr("class", "bs_circle").style("fill", "#29B0B3").style("stroke", "#E8EEEF").style("stroke-width", "2px")

                .attr("r", 3.5);



        g.selectAll("circle")
                .data(data)

                .enter()
                .insert("circle")
                .attr("fill", "#49D2D9")
                .style("opacity", "0.4")
                .style("pointer-events", "all")
                .on("mouseover", function (d) {
                    $(this).css("opacity", 1);
                    var valueStr = '';
                    if (d.value) {
                        valueStr = '<br><span><span style="color:#000;">Value: </span>' + d.value + '</span>'
                    }
                    $(".line_Chart_tooltip").html('<span><span style="color:#000;"> YEAR: </span>' + d.year + '</span>' + valueStr);
                    return $(".line_Chart_tooltip").css("visibility", "visible");
                })
                .on("mousemove", function () {
                    $(".line_Chart_tooltip").css("top", (d3.event.pageY - 10) + "px")
                    return  $(".line_Chart_tooltip").css("left", (d3.event.pageX + 10) + "px");

                })
                .on("mouseout", function () {
                    $(this).css("opacity", 0.4);
                    //hide tool-tip
                    return $(".line_Chart_tooltip").css("visibility", "hidden");
                })

                .attr("cx", function (d) {
                    return x((d.year));
                })
                .attr("r", function (d) {
                    return 5;
                })

                .attr("cy", function (d) {
                    return y(d.value)
                })

    }

}