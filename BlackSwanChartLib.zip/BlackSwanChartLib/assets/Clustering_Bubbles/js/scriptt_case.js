var clusterbubbleData = [];//array of data
$(document).ready(function () {
    
    var options ={
         header: "RISK RATIO",//Heading of Chart
Uri : "/proxy/api/cases/6eb696d9ccbd41b98c8f7eb12e2b9242/risk",//"proxy/api/cases/6eb696d9ccbd41b98c8f7eb12e2b9242/risk";//Url of data
container : "#example6",
height:500
    }
    ClusterBubble(options);//calling ClusterBubble function
});

//---------------------------------------------------------------------------
/**
*Function to call a function to plot ClusterBubble chart and to call function on window resize
*/


function ClusterBubble(options)
{
    loadclusterBubbleChart(options);

//responsivenss
    $(window).on("resize", function () {
        $("#example6").empty();
        new clusterbubbleChart(options);
    })


//---------------------------------------------------------------------------
/**
*Function to load data to plot ClusterBubble chart 
*/

function loadclusterBubbleChart(options) {
$(options.container).siblings(".headerDiv").html(options.header);
    d3.json(options.Uri, function (error, data) {
        clusterbubbleData = handleClusteredChartData(data.body);
        options.data=clusterbubbleData;
        var exampleChart = new clusterbubbleChart(options);

    });
}


//---------------------------------------------------------------------------
/**
*Function to handle data according to format of ClusterBubble Chart library
*/

function handleClusteredChartData(data) {
    var lowRiskArray = [];
    var mediumRiskArray = [];
    var highRiskArray = [];
    $.each(data, function (i, d) {
        var cumilativeRisk = getriskRation(d.direct, d.indirect, d.transactional)
        if (cumilativeRisk > 60) {
            highRiskArray.push({
                "name": d.name,
                "group": "HIGH",
                "size": cumilativeRisk
            });
        } else if (cumilativeRisk > 40) {
            mediumRiskArray.push({
                "name": d.name,
                "group": "MEDIUM",
                "size": cumilativeRisk
            });
        } else {
            lowRiskArray.push({
                "name": d.name,
                "group": "LOW",
                "size": cumilativeRisk
            });
        }
    });
    var finalData = [{
            "label": "LOW",
            "value": lowRiskArray.length,
            "children": lowRiskArray
        }, {
            "label": "MEDIUM",
            "value": mediumRiskArray.length,
            "children": mediumRiskArray
        }, {
            "label": "HIGH",
            "value": highRiskArray.length,
            "children": highRiskArray
        }];
    return finalData;
}
function getriskRation(direct, indirect, transactional) {
    return (1 - [(1 - direct) * (1 - indirect) * (1 - transactional)]) * 100;
}
}