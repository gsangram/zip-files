
function gitVisualChart(gitvisOptions) {
    var ghcs = {
        users: {}

    };
    var vis = {
        sC: function (a, b) {
            return d3.ascending(b.size, a.size);
        },
        visualLenght: function (txt) {
            return txt.clientWidth || txt.getComputedTextLength();
        }
    };
    if (gitvisOptions.container) {
        $(gitvisOptions.container).empty();
    }
    //--------------------------Initialize Values-----------------------------
    if (gitvisOptions) {
        this.container = gitvisOptions.container ? gitvisOptions.container : "body";
        this.data = (gitvisOptions.data) ? gitvisOptions.data : [];
        this.height = gitvisOptions.height ? gitvisOptions.height : 600;
        this.uri = gitvisOptions.uri;
        this.gitvisHeader = gitvisOptions.header ? gitvisOptions.header : "git vis CHART";

        this.randomIdString = Math.floor(Math.random() * 10000000000);
    } else {
        console.error('git visualizer Chart Initialization Error : git visualizer Chart Params Not Defined');
        return false;
    }
    //set width equal to height if width is more than height
    
    $(this.container).css({"width": "100%", "height": "100%"});
    var randomSubstring = this.randomIdString;
    var chartContainerdiv = '<div class="chartContainer chartContainer'+randomSubstring+'"  align="center" style="width: 100%; margin: auto; margin-top: 0px; font-size: 14px;font-family: roboto-regular;"> <div class="graphBox" style="margin: auto; background-color: #374c59; width: 100%;left: 0px;top: 0px;overflow: hidden;position: relative;"> <div class="headerDiv" style="font-weight:bold;background-color: #425661;text-align: left;color: #239185; border-bottom: 1px solid rgba(192, 192, 192, 0.47);width: 100%; line-height: 2.5;font-size: 16px ;padding-left: 5px;">' + this.gitvisHeader + '</div><div id="gitvis_chart_div' + randomSubstring + '" class="chartContentDiv" style="width: 100%;"></div> </div></div>'
    $(this.container).html(chartContainerdiv);
    var chart_container = "#gitvis_chart_div" + randomSubstring;
    this.width = gitvisOptions.width ? gitvisOptions.width : $(chart_container).width();
    if (this.height > this.width) {
        this.height = this.width;
    }else {
        $('.chartContainer'+randomSubstring).css("width",this.height)
    }
    var h = this.height + 50;
    if ($(chart_container).siblings(".headerDiv").find(".bstheme_menu_button").length == 0)
        var header_options = '<div style="float: right; padding: 0 10px; cursor: pointer;" class="bstheme_menu_button bstheme_menu_button_' + randomSubstring + '" data-toggle="collapse" data-target="#opt_' + randomSubstring + '"><i class="fa fa-ellipsis-v" aria-hidden="true"></i><div class="bstheme_options" style="position:absolute;right:10px;z-index:2000"> <div style="display:none;" id="opt_' + randomSubstring + '" class="collapse"><span class="header_refresh_' + randomSubstring + '"><i class="fa fa-refresh" aria-hidden="true"></i></span> <span class="header_table_' + randomSubstring + '"> <i class="fa fa-table" aria-hidden="true"></i></span> <span class="header_chart_' + randomSubstring + '" style="display:none" ><i class="fa fa-bar-chart" aria-hidden="true"></i></span></div></div> </div>';
    $(chart_container).siblings(".headerDiv").append(header_options);
    var actualOptions = jQuery.extend(true, {}, gitvisOptions);
    var data = this.data;
   
    //define tooltip
    $(".gitvis_Chart_tooltip").remove();

    $('body').append('<div id = "tool_tip_gitvis' + randomSubstring + '" class="gitvis_Chart_tooltip" style="position: absolute; opacity: 1; pointer-events: none; visibility: hidden;background-color:#0cae96;  padding: 10px;border-radius: 5px; border: 1px solid gray;font-size: 10px;color:black;"><span style=" font-size: 12px; position: absolute; white-space: nowrap;  margin-left: 0px; margin-top: 0px; left: 8px; top: 8px;"><span style="font-size:10px" class="tool_tip_x_val"></span><table><tbody><tr><td style="padding:0"> </td><td style="padding:0"><b>216.4 mm</b></td></tr><tr><td style="color:#434348;padding:0">New York: </td><td style="padding:0"><b>91.2 mm</b></td></tr><tr><td style="color:#90ed7d;padding:0">London: </td><td style="padding:0"><b>52.4 mm</b></td></tr><tr><td style="color:#f7a35c;padding:0">Berlin: </td><td style="padding:0"><b>47.6 mm</b></td></tr></tbody></table></span></div>');
    var tool_tip = $("#tool_tip_gitvis" + randomSubstring)
    var containerid = this.container;
    $(chart_container).css("height", this.height ? this.height : 600);
    init(chart_container, data);
    var colors = {
        additions: "#ddffdd",
        deletions: "#ffdddd",
        changes: "#FFF1DD",
        center: "#FF6600",
        stroked: "#f9f9f9",
        addedFile: "#A5EC6E",
        modifiedFile: "#FFB877",
        deletedFile: "#FF77B5",
        decolor: "#888888"
    };

    function toRgba(color, a) {
        color = d3.rgb(color);
        return "rgba(" + [color.r, color.g, color.b, a || 1] + ")";
    }
   
    var  svg_cs, svg, w, h;


    function applyParams(data) {
        parseRepos(data)
    }

    function redrawRepos() {

        ghcs.redrawReposTimer = setTimeout(function () {
            var repos = ghcs.users
                    && ghcs.users[ghcs.login]
                    && ghcs.users[ghcs.login].repos
                    ? ghcs.users[ghcs.login].repos
                    : null;

            vis.redrawRepos(repos);

            vis.redrawLangHg(repos
                    ? d3.nest().key(function (d) {
                return d.nodeValue.lang;
            }).entries(ghcs.users[ghcs.login].repos)
                    : null);
            ghcs.redrawReposTimer = null;
        }, 100);
    }

    //------------------------------------------------------------------------------
    /**
     * 
     * Function to highlight circles when hover on legends
     */
    function meiRepo(d) {
        d._g
                && d._g.selectAll("circle")
                .style("stroke", d3.rgb(colors.decolor).darker())
                .style("fill", toRgba(colors.decolor, vis.forceRep.opt(vis.forceRep.radO(d))))
                && d._g.selectAll("text")
                .style("fill", d3.rgb(colors.decolor).darker());
    }
    //------------------------------------------------------------------------------
    /**
     * 
     * Function to de-highlight circles when mouse out of legends
     */
    function moiRepo(d) {
        var sel = vis.forceRep.selected == d;

        d._g
                && d._g.selectAll("circle")
                .style("stroke", d3.rgb(vis.forceRep.colors(d.nodeValue.lang)))
                .style("fill",
                        sel
                        ? d3.rgb(vis.forceRep.colors(d.nodeValue.lang)).brighter()
                        : toRgba(vis.forceRep.colors(d.nodeValue.lang), vis.forceRep.opt(vis.forceRep.radO(d))))
                && d._g.selectAll("text")
                .style("fill",
                        sel
                        ? d3.rgb(vis.forceRep.colors(d.nodeValue.lang)).darker()
                        : d3.rgb(vis.forceRep.colors(d.nodeValue.lang)).brighter());
    }
//initialize chart plotting
    function init(id, data) {
        svg_cs = d3.select(id);
        svg = svg_cs.append("svg");
        w = $(id).width() || document.body.clientWidth;
        h = $(id).height() || document.body.clientHeight;

        svg.attr("width", w).attr("height", h);
        initGraphics(svg);
        applyParams(data);
    }
    //--------------------------------------------------------------------------
    /**
     * Function to parse data in required format
     */
    function parseRepos(data) {
        if (data) {
            ghcs.users[ghcs.login] = ghcs.users[ghcs.login] || {};
            ghcs.users[ghcs.login].repos = (ghcs.users[ghcs.login].repos || []).concat(
                    data.filter(function (d) {
                        return !d.hasOwnProperty("nodeValue");
                    }).map(function (d) {
                d = {
                    x: (Math.random() * w) || 1,
                    y: (Math.random() * h) || 1,
                    visible: true,
                    nodeValue: {
                        id: d.id,
                        name: d.name,
                        size: d.size,
                        lang: d.type || "Other"
                    }
                };
                return d;
            })
                    );

        }
        redrawRepos();
    }

//graph functionality
    function initGraphics(svg) {
        vis.layers = (function (data) {
            var ls = {_data: data};

            svg.selectAll("g.layer")
                    .data(data, function (d) {
                        return d.name
                    })
                    .enter()
                    .append("g")
                    .each(function (d) {
                        ls[d.name] = d3.select(this).attr("class", "layer").attr("width", w).attr("height", h);
                        ls[d.name].getOrder = function () {
                            return d.order;
                        };
                        ls[d.name].toFront = function () {
                            d.order &&
                                    vis.layers.ordering(this, 0);
                            return ls[d.name];
                        };
                        ls[d.name].hide = function () {
                            ls[d.name].visible = false;
                            if (ls[d.name].datum().name == "repo" && vis.forceRep)
                                vis.forceRep.stop();
                            ls[d.name].style("display", "none");
                            return ls[d.name];
                        };
                        ls[d.name].show = function () {
                            ls[d.name].visible = true;
                            if (ls[d.name].datum().name == "repo" && vis.forceRep)
                                vis.forceRep.resume();
                            ls[d.name].style("display", null);
                            return ls[d.name];
                        };
                        ls[d.name].visible = true;
                    });
            return ls;
        })([
            {name: "repo", order: 2},
            {name: "stat", order: 1},
            {name: "show", order: 0}
        ]);

        vis.layers.ordering = function (layer, order) {
            function s(a, b) {
                return d3.ascending(b.order, a.order);
            }
            var _d = (layer instanceof Array || layer instanceof Object ? layer : this[layer]);
            _d = _d ? (_d instanceof Array ? _d.datum() : _d) : null;
            if (_d) {
                this._data.forEach(function (d) {
                    _d != d && d.order >= order && d.order++;
                });
                _d.order = order;
                svg.selectAll("g.layer").sort(s);
            }
            return this;
        };

    }
//------------------------------------------------------------------------------
    /**
     * 
     * Function to plot bubbles
     */
    (function (vis) {
        vis.clearRepos = function () {
            if (vis.forceRep) {
                vis.forceRep.stop().nodes([]);
                delete vis.forceRep;
            }
        };
//define transition
        function tr(d) {
          
            return "translate(" + [d.x, d.y] + ")";
        }
//define zoom
        var zoom = d3.behavior.zoom()
                .scaleExtent([.5, 1])
                ;

        function zoomed() {
            this.attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
        }
        //------------------------------------------------------------------------------
        /**
         * 
         * Function to plot repos
         */
        vis.redrawRepos = function (data, layout) {

            layout = layout || vis.layers.repo;

            if (!data) {
                vis.clearRepos();
                return;
            }

            vis.forceRep = vis.forceRep || d3.layout.force()
                    .size([w, h])
                    .friction(.99)
                    .gravity(.005)
                    .charge(function (d) {
//                return 0;
                        return -vis.forceRep.radius(vis.forceRep.rad(d)) / 2;
                    })
                    .on("tick", tick);


            vis.forceRep.rad = vis.forceRep.rad || function (d) {
                return d.nodeValue.id;
            };
//
            vis.forceRep.radO = vis.forceRep.radO || function (d) {
                return d.nodeValue.id - vis.forceRep.id;
            };

            data = data.sort(function (a, b) {
                return a.nodeValue.id - b.nodeValue.id;
            });

            var kof = (h > w ? h : w) / (4 * ((Math.log(data.length || 1) / Math.log(1.5)) || 1));

            var r = [kof / 5, kof];

            (vis.forceRep.radius || (vis.forceRep.radius = d3.scale.linear()))
                    .range(r)
                    .domain(d3.extent(data, vis.forceRep.rad));

            data.length == 1 && vis.forceRep.radius.domain([vis.forceRep.radius.domain()[0] - 1, vis.forceRep.radius.domain()[1]]);

            (vis.forceRep.opt || (vis.forceRep.opt = d3.scale.log().range([.01, .9])))
                    .domain(
                            d3.extent(data, vis.forceRep.radO)
                            );
            vis.forceRep.colors = vis.reposColors || (vis.reposColors = d3.scale.category10());

            vis.forceRep.visible = vis.forceRep.visible || function (d) {
                return vis.visualLenght(this) < vis.forceRep.radius(vis.forceRep.rad(d)) * 2.1 ? null : "hidden";
            };

            vis.forceRep.appCT = vis.forceRep.appCT || function (g) {
                g.each(function (d) {
                    d._g = d3.select(this);
                });

                g.append("circle")
                        .attr("r", 0);

                g.append("text")
                        .attr("text-anchor", "middle")
                        .attr("dy", ".31em")
                        .text(function (d) {
                            return d.nodeValue.name;
                        });

                g.append("line")
                        .attr("class", "lA")
                        .attr("x", 0)
                        .attr("y", 0)
                        .style("stroke-width", 1)
                        .style("stroke", "white");

                g.append("line")
                        .attr("class", "lB")
                        .attr("x", 0)
                        .attr("y", 0)
                        .style("stroke-width", 1)
                        .style("stroke", "red");
            };

            vis.forceRep.upCT = vis.forceRep.upCT || function (g) {
                g.selectAll("circle")
                        .style("stroke-width", 1)
                        .style("stroke", function (d) {
                            return d3.rgb(vis.forceRep.colors(d.nodeValue.lang));
                        })
                        .style("fill", function (d) {
                            return toRgba(d3.rgb(vis.forceRep.colors(d.nodeValue.lang)), vis.forceRep.opt(vis.forceRep.radO(d)));
                        })
                        .transition()
                        .duration(2500)
                        .ease("elastic")
                        .attr("r", function (d) {                          
                            return vis.forceRep.radius(vis.forceRep.rad(d));
                        });
                g.selectAll("text")
                        .style("fill", function (d) {
                            return d3.rgb(vis.forceRep.colors(d.nodeValue.lang)).brighter();
                        })
                        .style("visibility", vis.forceRep.visible);
            };

            vis.forceRep
                    .stop()
                    .nodes(data)
                    .start();

            if (!vis.reposGroup) {
                layout.append("rect")
                        .attr("width", w)
                        .attr("height", h)
                        .style("fill", "none")
                        .style("pointer-events", "all");
                vis.reposGroup = layout.append("g");
                zoom.center([w * .5, h * .5])
                        .on("zoom", zoomed.bind(vis.reposGroup));
                layout.call(zoom)
                        .on("mousedown.zoom", null)
                        .on("touchstart.zoom", null)
                        .on("touchmove.zoom", null)
                        .on("touchend.zoom", null);
            }

            vis.forceRep.circle = vis.reposGroup.selectAll(".cRepo")
                    .data(data, function (d) {
                        return d.nodeValue.id
                    })
                    ;


            vis.forceRep.circle.enter()
                    .append("g")
                    .attr("class", "cRepo")
                    .attr("transform", tr)
                    .on("mouseover", function (d) {

                        tool_tip.html('<span> Name: ' + d.nodeValue.name + '</span><br><span> Occurrence: ' + d.nodeValue.size + '</span><br><span> Type: ' + d.nodeValue.lang + '</span>');
                        return tool_tip.css("visibility", "visible");
                    })
                    .on("mousemove", function () {
                        tool_tip.css("top", (d3.event.pageY - 10) + "px")
                        return  tool_tip.css("left", (d3.event.pageX + 10) + "px");

                    })
                    .on("mouseout", function () {

                        return tool_tip.css("visibility", "hidden");
                    })

                    .call(vis.forceRep.drag)

                    .call(vis.forceRep.appCT);

            vis.forceRep.circle.call(vis.forceRep.upCT);

            vis.forceRep.circle.exit().remove();
            //------------------------------------------------------------------
            /**
             *Function to move circle
             */
            function tick(e) {
//                return
                var quadtree = d3.geom.quadtree(vis.forceRep.nodes());
                console.log(e.alpha)
                
                vis.forceRep.circle
                        .each(cluster(/*0.25*/10 * e.alpha * e.alpha))
//                        .each(cluster(0.05))
//                        .each(cluster(0.01))
                        .each(collide(0.5, quadtree))
                        .attr("transform", tr);
                if (e.alpha < .5)
                    vis.forceRep.resume();
            }

            // Move d to be adjacent to the cluster node.
            function cluster(alpha) {
                vis.forceRep.cenralNodes = vis.forceRep.cenralNodes || {};

                // Find the largest node for each cluster.
                vis.forceRep.nodes().forEach(function (d, n) {
                    n = vis.forceRep.cenralNodes[d.nodeValue.lang];
                    (!n || !n.visible || vis.forceRep.radO(d) > vis.forceRep.radO(n)) && d.visible &&
                            (vis.forceRep.cenralNodes[d.nodeValue.lang] = d);
                });

                return function (d) {
                    var node = vis.forceRep.cenralNodes[d.nodeValue.lang],
                            l,
                            r,
                            x,
                            y;

                    if (node == d || !d.visible)
                        return;

                    x = d.x - node.x;
                    y = d.y - node.y;
                    l = Math.sqrt(x * x + y * y);
                    r = vis.forceRep.radius(vis.forceRep.rad(d)) + vis.forceRep.radius(vis.forceRep.rad(node)) * 1.5;
                    if (l != r) {
                        l = (l - r) / (l || 1) * (alpha || 1);
                        x *= l;
                        y *= l;

                        d.x -= x;
                        d.y -= y;

                        node.x += x;
                        node.y += y;
                    }
                };
            }

            // Resolves collisions between d and all other circles.
            function collide(alpha, quadtree) {
                return function (d) {
                    var padding = vis.forceRep.radius.range()[1] * 1.5,
                            r = vis.forceRep.radius(vis.forceRep.rad(d)) + padding,
                            nx1 = d.x - r,
                            nx2 = d.x + r,
                            ny1 = d.y - r,
                            ny2 = d.y + r;
                    quadtree.visit(function (quad, x1, y1, x2, y2) {
                        if (quad.point && (quad.point !== d) && d.visible && quad.point.visible) {
                            var x = d.x - quad.point.x,
                                    y = d.y - quad.point.y,
                                    l = Math.sqrt(x * x + y * y),
                                    /*+ (d.nodeValue.lang !== quad.point.nodeValue.lang) * padding*/
                                    r = vis.forceRep.radius(vis.forceRep.rad(d)) +
                                    vis.forceRep.radius(vis.forceRep.rad(quad.point)) * 1.02;
                            if (l < r) {
                                l = (l - r) / (l || 1) * (alpha || 1);

                                x *= l;
                                y *= l;

                                d.x -= x;
                                d.y -= y;

                                quad.point.x += x;
                                quad.point.y += y;
                            }
                        }
                        return x1 > nx2
                                || x2 < nx1
                                || y1 > ny2
                                || y2 < ny1;
                    });
                };
            }
        };
    })(vis || (vis = {}));
//------------------------------------------------------------------------------
    /**
     *Function for legendss
     */
    (function (vis) {
        vis.clearLangHg = function () {
            vis.layers && vis.layers.repo && vis.layers.repo.langHg && vis.layers.repo.langHg.selectAll("*")
                    .transition()
                    .duration(750)
                    .ease("elastic")
                    .remove();
        };

        vis.redrawLangHg = function (data, layout) {
            layout = layout || vis.layers.repo;

            if (!data) {
                vis.clearLangHg();
                return;
            }

            data = data.sort(function (a, b) {
                return d3.ascending(a.key, b.key);
            });

            var w_hg = w / 4,
                    h_hg = h / 6,
                    m = {left: 10, top: 10, right: 10, bottom: 10},
            pos = {top: h - h_hg - m.bottom - m.top, left: m.left};

            var x = d3.scale.ordinal()
                    .rangeRoundBands([0, 28 * data.length], .2)
                    .domain(data.map(function (d) {
                        return d.key;
                    }));
            var xc = x.rangeBand() / 2;

            var y = d3.scale.linear()
                    .domain([0, d3.max(data, function (d) {
                            return d.values.length;
                        })])
                    .range([h_hg, 0]);

            if (layout.langHg && layout.langHg.empty())
                layout.langHg = null;

            layout.langHg = (layout.langHg || layout.insert("g", ":last-child"))
                    .attr("class", "langHg")
                    .attr("width", w_hg + m.left + m.right)
                    .attr("height", h_hg + m.top + m.bottom)
                    .attr("transform", "translate(" + [pos.left, pos.top] + ")");

            function me(d) {
                $(this).find(".barSelect").css({
                    "fill-opacity": ".6",
                    "stroke-opacity": ".6",
                    "-webkit-transition": "all .5s",
                    "-moz-transition": "all .5s",
                    "-o-transition": "all .5s",
                    "transition": "all .5s"
                })
                vis.forceRep.nodes().filter(function (k) {
                    return k.nodeValue.lang != d.key;
                }).forEach(meiRepo);
            }

            function mo(d) {
                $(this).find(".barSelect").css({
                    "fill-opacity": "0",
                    "stroke-opacity": "0",
                    "-webkit-transition": "all 1.5s",
                    "-moz-transition": "all 1.5s",
                    "-o-transition": "all 1.5s",
                    "transition": "all 1.5s"
                })
                vis.forceRep.nodes().filter(function (k) {
                    return k.nodeValue.lang != d.key;
                }).forEach(moiRepo);
            }

            function appendItems(g) {
                g.append("path")
                        .attr("class", "hLine")
                        .style("stroke", "rgba(255, 255, 255, .3)");

                g.append("text")
                        .attr("class", "tLang")
                        .style("fill", function (d) {
                            return d3.rgb(vis.forceRep.colors(d.key));
                        })
                        .attr("dy", ".33em")
                        .attr("dx", "-6px")
                        .attr("transform", "rotate(90)")
                        .style("text-anchor", "end")
                        .text(function (d) {
                            return d.key;
                        })
                        .each(function () {
                            var pr = d3.select(this.parentNode);
                            pr.insert("rect", ":first-child")
                                    .attr("class", "barSelect")
                                    .attr("fill", "rgba(244, 244, 244, .2)")
                                    .style("stroke", "#000")
                                    .style("stroke-opacity", "0")
                                    .style("stroke-width", "1px")
                                    .style("fill", "#f9f9f9")
                                    .style("fill-opacity", "0")
                                    .style("-webkit-transition", "all 1.5s")
                                    .style("-moz-transition", "all 1.5s")
                                    .style("-o-transition", "all 1.5s")
                                    .style("transition", "all 1.5s");
                        });

                var gg = g.append("g")
                        .attr("class", "barChain");

                gg.append("path")
                        .attr("class", "vLine")
                        .style("stroke", function (d) {
                            return d3.rgb(vis.forceRep.colors(d.key)).darker().darker();
                        })
                        .attr("transform", "translate(" + [-.5, 0] + ")")
                        .attr("d", "M0.5,0 L0.5,0");

                gg.append("circle")
                        .style("fill", function (d) {
                            return d3.rgb(vis.forceRep.colors(d.key)).darker().darker();
                        })
                        .attr("r", 2);

                var dg = gg.append("g")
                        .attr("class", "dCircle")
                        .attr("transform", "translate(" + [0, 0] + ")");

                dg.append("circle")
                        .attr("class", "bSubCircle")
                        .style("fill", function (d) {
                            return d3.rgb(vis.forceRep.colors(d.key));
                        })
                        .style("stoke", function (d) {
                            return d3.rgb(vis.forceRep.colors(d.key)).darker();
                        })
                        ;

                dg.append("circle")
                        .style("fill", function (d) {
                            return d3.rgb(vis.forceRep.colors(d.key)).darker().darker();
                        })
                        .attr("r", 2)
                        ;

                dg.append("text")
                        .attr("text-anchor", "middle")
                        .attr("dy", ".32em")
                        .style("fill", function (d) {
                            return d3.rgb(vis.forceRep.colors(d.key)).brighter();
                        })
                        ;
            }

            var bar = layout.langHg.selectAll(".barLang")
                    .data(data, function (d) {
                        return d.key;
                    });

            bar.exit().remove();

            bar.enter()
                    .append("g")
                    .attr("transform", "translate(" + [0, -xc * 2] + ")")
                    .attr("class", "barLang")
                    .on("mouseover", me)
                    .on("mouseout", mo)
                    .call(appendItems);

            bar.transition()
                    .duration(3500)
                    .ease("elastic")
                    .attr("transform", function (d) {
                        return "translate(" + [x(d.key), -xc * 2] + ")";
                    });

            bar.each(function (k) {
                d3.select(this).selectAll("*")
                        .datum(k);
            });
            bar.selectAll("path.hLine")
                    .attr("d", "M0,0 L" + (xc * 2) + ",0");

            bar.selectAll("text.tLang")
                    .attr("y", -xc)
                    .each(function (d) {
                        var pr = d3.select(this.parentNode);
                        pr.selectAll("rect.barSelect")
                                .attr("transform", "translate(" + [-xc * .2, -(vis.visualLenght(this) + 6 + xc * .4)] + ")")
                                .attr("width", xc * 2.4)
                                .attr("height", (vis.visualLenght(this) + 6 + xc * .4) + h_hg - y(d.values.length) + xc * 2.4);
                    });

            var gg = bar.selectAll("g.barChain")
                    .attr("transform", "translate(" + [x.rangeBand() / 2, 0] + ")");

            var dg = gg.selectAll("g.dCircle");

            dg.selectAll("circle.bSubCircle")
                    .attr("r", xc);
            dg.selectAll("text")
                    .text(function (d) {
                        return d.values.length;
                    });

            dg.transition()
                    .delay(100)
                    .duration(3500)
                    .ease("elastic")
                    .attr("transform", function (d) {
                        return "translate(" + [0, h_hg - y(d.values.length) + xc] + ")";
                    });

            gg.selectAll("path.vLine").transition()
                    .duration(3500)
                    .ease("elastic")
                    .attr("d", function (d) {
                        return "M0.5,0 L0.5," + (h_hg - y(d.values.length) + xc);
                    });
        }
    })(vis || (vis = {}));

    //------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */
    $("body").on("click", ".bstheme_menu_button_" + randomSubstring, function () {

        var id = ($(this).attr("data-target"));
        if ($(id).css("display") == "none") {
            $(id).css("display", "inline-block");
        } else {
            $(id).css("display", "none");
        }
    });
//------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */
    $("body").on("click", ".header_refresh_" + randomSubstring, function () {
        var chartId = $(this).parent().parent().parent().parent().siblings("div").attr("id");
        if ("#" + chartId == chart_container) {
            $(containerid).empty();
            chartgitVisual(actualOptions);
        }
    });
//------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */
    var a = parseInt((this.height) / 55);

    $("body").on("click", ".header_table_" + randomSubstring, function () {
        $(chart_container).empty();
        $(this).css("display", "none");
        $(".header_chart_" + randomSubstring).css("display", "inline-block");
        var tbl = "<div id ='gitvis_table_" + randomSubstring + "'><table class='table-striped' style='width:100%;padding:10px;background-color:#283C45;color:#5A676E;'><thead><tr><th>Name</th><th>Occurrence</th><th>Type</th></tr></thead><tbody>";
        $.each(data, function (index, value) {
            tbl = tbl + "<tr><td>" + (value.name.toUpperCase()) + "</td><td>" + value.size + "</td><td>" + (value.type ? value.type : "-") + "</td></tr>"

        });
        tbl = tbl + "</tbody></table></div>";
        $(chart_container).append(tbl);

        $(".table-striped").DataTable({"bLengthChange": false, "iDisplayLength": a, "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (iDisplayIndex % 2 == 1) {
                    //even color
                    $('td', nRow).css('background-color', '#32464F');
                } else {
                    $('td', nRow).css('background-color', '#283C45');
                }
            }});



        $("#gitvis_table_" + randomSubstring + " tr:first").css("background-color", "#0CB29A");
        var id1 = $("#gitvis_table_" + randomSubstring).children('div').find('div').eq(0);
        var id2 = $("#gitvis_table_" + randomSubstring).children('div').find('div').eq(1);
        var id3 = $("#gitvis_table_" + randomSubstring).children('div').find('div').eq(2);
        var id1attr = id1.attr("id");
        var id2attr = id2.attr("id");
        var id3attr = id3.attr("id");



        $("#" + id1attr + " " + "label").css("color", "#666666")
        $("#" + id2attr + " " + "label").css("color", "#666666")
        $("#" + id3attr).css("color", "#666666")

        $(" .dataTables_filter input").css({"margin-left": "0.5em", "position": "relative", "border": "0", "min-width": "240px",
            "background": "transparent",
            "border-bottom": "1px solid #666666",
            " border-radius": " 0",
            "padding": " 5px 25px",
            "color": "#ccc",
            "height": " 30px",
            "-webkit-box-shadow": " none",
            "box-shadow": " none"
        });
    });
//------------------------------------------------------------------------------
    /**
     * Fuction to handle show hide of header options
     */
    $("body").on("click", ".header_chart_" + randomSubstring, function () {
        var chartId = $(this).parent().parent().parent().parent().siblings("div").attr("id");
        if ("#" + chartId == chart_container) {
            $(this).css("display", "none");
            $(".header_table_" + randomSubstring).css("display", "inline-block");
            $(containerid).empty();

            new gitVisualChart(actualOptions);
        }
    });

}