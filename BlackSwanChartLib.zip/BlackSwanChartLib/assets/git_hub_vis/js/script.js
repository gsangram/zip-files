$(document).ready(function () {
      var height = sessionStorage.getItem('f14');

      function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
var widthfrmUrl = getParameterByName("width");
var heightfrmUrl = parseInt(getParameterByName("height"));
if(heightfrmUrl){
height = heightfrmUrl- 50;
}

console.log(height)
    var options = {
        "container": "#example16", //Container id where chart will be appended
        "header": "GIT VIZUALIZER", //Heading of Chart
        "uri": "data/visual.json", //Url of data
        "height": height
    };
    chartgitVisual(options);//calling chartCaseTimeLine function


});
//---------------------------------------------------------------------------
/**
 *Function to call a function to plot CaseTimeLine chart and to call function on window resize
 */
 var gitVisualData = [];//array of data
function chartgitVisual(options)
{
   
    var current_options= options;
    loadgitVisualChart(current_options);
//responsivenss
    $(window).on("resize", function () {
        if ($(current_options.container).find("svg").length != 0) {
            $(current_options.container).empty();            
            new gitVisualChart(current_options);
        }
    });
//---------------------------------------------------------------------------
    /**
     *Function to load data to plot CaseTimeLine chart 
     */
    function loadgitVisualChart(current_options) {
        var uri = current_options.uri;
        d3.json(uri, function (error, resp) {
            var data = handlegivisualData(resp);
            gitVisualData = data
            options.data = jQuery.extend(true, [], data);
            var chart_options = jQuery.extend(true, {}, options);
            new gitVisualChart(chart_options);

        });
    }
    //--------------------------------------------------------------------------
    /**
     * Function to handle data for git visualizer
     */
    function handlegivisualData(data){
        var newData =[];
        var keys = d3.keys(data);
        $.each(keys,function(i,d){
            var innerkeys = d3.keys(data[d])
            $.each(innerkeys,function(i1,v){
                newData.push({
                    id:newData.length,
                    "name":v,
                    "size":data[d][v],
                    "type": (d.substr(0,1).toUpperCase() + d.substr(1))
                });
            });
        });
        
        return newData;
    }

}


