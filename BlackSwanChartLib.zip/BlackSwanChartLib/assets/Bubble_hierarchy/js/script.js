$(document).ready(function () {
    var height = sessionStorage.getItem('f18');

    function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
var widthfrmUrl = getParameterByName("width");
var heightfrmUrl = parseInt(getParameterByName("height"));
if(heightfrmUrl){
height = heightfrmUrl -50;
}
   

    var options = {
        "container": "#example25", //Container id where chart will be appended
        "header": "BUBBLE HIERARCHY", //Heading of Chart
        "uri": "data/data.json", //Url of data
        "height": parseInt(height)
    };
    chartBubbleHierarchy(options);//calling chartCaseTimeLine function


});
//---------------------------------------------------------------------------
/**
 *Function to call a function to plot CaseTimeLine chart and to call function on window resize
 */

function chartBubbleHierarchy(options)
{
    var BubbleHierarchyData = [];//array of data
    var current_options = options;
    loadBubbleHierarchyChart(current_options);
//responsivenss
    $(window).on("resize", function () {
        if ($(current_options.continer).find("svg").length != 0) {
            $(current_options.container).empty();
            var data = jQuery.extend(true, [], BubbleHierarchyData);
            new BubbleHierarchyChart(options);
        }
    });
//---------------------------------------------------------------------------
    /**
     *Function to load data to plot CaseTimeLine chart 
     */
    function loadBubbleHierarchyChart(current_options) {
        var uri = current_options.uri;
        d3.json(uri, function (error, data) {
            options.data = jQuery.extend(true, [], data);
            var chart_options = jQuery.extend(true, {}, options);
            var exampleChart = new BubbleHierarchyChart(chart_options);

        });
    }

}

