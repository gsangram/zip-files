$(document).ready(function () {
    var height = sessionStorage.getItem('f3');

     function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
var widthfrmUrl = getParameterByName("width");
var heightfrmUrl = parseInt(getParameterByName("height"));
if(heightfrmUrl){
height = heightfrmUrl;
}

    var options = {
        height: height,
        container: '#example3', //Container id where chart will be appended
        header: "ENTITY IN FOCUS", //Heading of Chart
        uri: "/proxy/api/cases/all"//Url of data "proxy/api/cases/all"

    }
    chartBubble(options);//calling chartBubble function


});
//---------------------------------------------------------------------------
/**
 *Function to call a function to plot Bubble chart and to call function on window resize
 */

function chartBubble(options)
{

    var container = options.container;//Container id where chart will be appended

    var bubbleHeader = options.container;//Heading of Chart
    var bubbleuri = options.uri;//Url of data
    loadBubbleChart(options);
//responsivenss
    $(window).on("resize", function () {

        if ($(options.container).find("svg").length != 0) {
            $(options.container).empty();
            new bubbleChart(options);
        }
    })
//---------------------------------------------------------------------------
    /**
     *Function to load data to plot Bubble chart 
     */
    function loadBubbleChart(options) {
        $(options.container).siblings(".headerDiv").html(options.Header);
        d3.json(options.uri, function (error, data) {
            bubbleData = handleBubbleData(data);
            options.data = bubbleData;
            new bubbleChart(options);

        });
    }
//---------------------------------------------------------------------------
    /**
     *Function to handle data according to format of Bubble Chart library
     */


    function handleBubbleData(data) {

        var keys = d3.keys(data);
        var newData = [];
        $.each(keys, function (i, d) {
            var newVlaues = [];
            var innerKeys = d3.keys(data[d]);
            $.each(innerKeys, function (i1, d1) {
                newVlaues.push({
                    "name": d1,
                    "size": data[d][d1]
                })
            });

            newData.push({
                "name": d,
                "children": newVlaues
            })
        });
        var finalData = {
            "children": newData
        };

        return finalData;
    }
}


