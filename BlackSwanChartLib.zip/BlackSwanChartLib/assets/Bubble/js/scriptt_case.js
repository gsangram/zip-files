$(document).ready(function () {
    
    var options ={
    container:'#example3',//Container id where chart will be appended
    header:"ENTITY IN FOCUS",//Heading of Chart
    uri:"/proxy/api/cases/6eb696d9ccbd41b98c8f7eb12e2b9242/risk"//Url of data "proxy/api/cases/all"
   
  }
    chartBubble(options);//calling chartBubble function
//    var bubbleChartId = "#example4";//Container id where chart will be appended
//    var bubbleHeader = "ENTITY IN FOCUS1";//Heading of Chart
//    var bubbleuri = "proxy/api/cases/6eb696d9ccbd41b98c8f7eb12e2b9242/risk";
//    chartBubble(bubbleChartId,bubbleHeader,bubbleuri);//calling chartBubble function

});
//---------------------------------------------------------------------------
/**
 *Function to call a function to plot Bubble chart and to call function on window resize
 */

function chartBubble(options)
{
    
    var container = options.container;//Container id where chart will be appended

    var bubbleHeader = options.container;//Heading of Chart
    var bubbleuri = options.uri;//Url of data
    loadBubbleChart(options);
//responsivenss
    $(window).on("resize",  function () {
       
        if($(options.container).find("svg").length != 0){
        $(options.container).empty();
        new bubbleChart(options);
        }
    })
//---------------------------------------------------------------------------
    /**
     *Function to load data to plot Bubble chart 
     */
    function loadBubbleChart(options) {
        $(options.container).siblings(".headerDiv").html(options.Header);
        d3.json(options.uri, function (error, data) {
            console.log(data);
            bubbleData = handleCaseBubbleData(data.body);
            options.data=bubbleData;
            var exampleChart = new bubbleChart(options);

        });
    }
//---------------------------------------------------------------------------
    /**
     *Function to handle data according to format of Bubble Chart library
     */


    function handleCaseBubbleData(data) {

        var nested_data = d3.nest()
                .key(function (d) {
                    return  d.type
                }).entries(data);

        var newData = [];
        $.each(nested_data, function (i, d) {
            var newVlaues = [];
            $.each(d.values, function (i1, d1) {
                newVlaues.push({
                    "name": d1.name,
                    "size": getriskRation(d1.direct, d1.indirect, d1.transactional)
                })
            });
            newData.push({
                "name": d.key,
                "children": newVlaues
            })
        });
        var finalData = {
            "children": newData
        };

        return finalData;
    }
    function getriskRation(direct, indirect, transactional) {
        return (1 - [(1 - direct) * (1 - indirect) * (1 - transactional)]) * 100;
    }
}
